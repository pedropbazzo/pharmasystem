package model;

public class Categoria {
	
	private int codCategoria;
	private String nomeCategoria;
	
	public Categoria() {
		// TODO Auto-generated constructor stub
	}
	
	public Categoria(int codCategoria, String nomeCategoria) {
		super();
		this.codCategoria = codCategoria;
		this.nomeCategoria = nomeCategoria;
	}

	public int getCodCategoria() {
		return codCategoria;
	}

	public void setCodCategoria(int codCategoria) {
		this.codCategoria = codCategoria;
	}

	public String getNomeCategoria() {
		return nomeCategoria;
	}

	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}
	
}