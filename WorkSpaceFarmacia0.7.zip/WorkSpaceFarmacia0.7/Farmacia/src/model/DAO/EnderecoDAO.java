package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import model.Endereco;
import util.Conexao;

public class EnderecoDAO {
	
	public static Endereco cadastrarEndereco(String logradouro, String numero, String complemento, 
			String bairro, String cidade, String estado, String cep) {
		
		System.out.println("Endere�o");
		Endereco end = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO endereco (logradouro, numero, complemento, bairro, cidade, estado, cep) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, logradouro);
			stmt.setString(2, numero);
			stmt.setString(3, complemento);
			stmt.setString(4, bairro);
			stmt.setString(5, cidade);
			stmt.setString(6, estado);
			stmt.setString(7, cep);
			
			if(stmt.executeUpdate()>0){
				end = new Endereco(logradouro, numero, complemento, bairro, cidade, estado, cep);

				ResultSet rs = stmt.getGeneratedKeys();
				if (rs.next()) {
					end.setCodEndereco((rs.getInt(1)));
				}
				
				rs.close();
			}

			con.close();
			stmt.close();
			

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return end;
	}
	
	public static List<Endereco> buscarTodosEndereco() {
		
		List<Endereco> lista = new LinkedList<>();
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM endereco";
		
		try {
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while(rs.next()){
				Endereco e = new Endereco();
				e.setLogradouro(rs.getString("logradouro"));
				e.setNumero(rs.getString("numero"));
				e.setComplemento(rs.getString("complemento"));
				e.setBairro(rs.getString("bairro"));
				e.setCidade(rs.getString("cidade"));
				e.setEstado(rs.getString("estado"));
				e.setCep(rs.getString("cep"));
				
				lista.add(e);
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return lista;
	}
	
	public static boolean excluirEndereco(int codEndereco){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "DELETE FROM endereco WHERE codEndereco = ? LIMIT 1";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, codEndereco);
			
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static boolean atualizarEndereco(String logradouro, String numero, String complemento, 
			String bairro, String cidade, String estado, String cep, int codEndereco){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "UPDATE endereco SET logradouro = ?, numero = ?, complemento = ?, bairro = ?, cidade = ?, estado = ?, cep = ? WHERE codEndereco = ?";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, logradouro);
			stmt.setString(2, numero);
			stmt.setString(3, complemento);
			stmt.setString(4, bairro);
			stmt.setString(5, cidade);
			stmt.setString(6, estado);
			stmt.setString(7, cep);
			stmt.setInt(8, codEndereco);
			
			ok = stmt.executeUpdate() > 0;

			con.close();
			stmt.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
}