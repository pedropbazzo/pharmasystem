package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import model.Cliente;
import model.Endereco;
import util.Conexao;

public class ClienteDAO {
	
	public static Cliente cadastrarCliente(String nome, String telefone, String email, String sexo, String cpf, String rg, String situacao, Date nascimento, Endereco endereco) {
		
		System.out.println("Cliente");
		Cliente cliente = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO cliente (nome, telefone, email, sexo, cpf, rg, situacao, nascimento, fkcodendereco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, nome);
			stmt.setString(2, telefone);
			stmt.setString(3, email);
			stmt.setString(4, sexo);
			stmt.setString(5, cpf);
			stmt.setString(6, rg);
			stmt.setString(7, situacao);
			stmt.setDate(8, new java.sql.Date(nascimento.getTime()));
			stmt.setInt(9, endereco.getCodEndereco());
			
			if(stmt.executeUpdate()>0){
				cliente = new Cliente(nome, telefone, email, sexo, cpf, rg, situacao, nascimento, endereco);

				ResultSet rs = stmt.getGeneratedKeys();
				if (rs.next()) {
					cliente.setCodigoCliente((rs.getInt(1)));
				}
				
				rs.close();
			}

			con.close();
			stmt.close();
			

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return cliente;
	}
	
	public static List<Cliente> buscarTodosCliente() {
		
		List<Cliente> lista = new LinkedList<>();
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM cliente";
		
		try {
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while(rs.next()){
				Cliente c = new Cliente();
				c.setNome(rs.getString("nome"));
				c.setTelefone(rs.getString("telefone"));
				c.setEmail(rs.getString("email"));
				c.setSexo(rs.getString("telefone"));
				c.setCpf(rs.getString("cpf"));
				c.setRg(rs.getString("rg"));
				c.setSituacao(rs.getString("situacao"));
				c.setNascimento(rs.getDate("nascimento"));
				
				lista.add(c);
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return lista;
	}
	
	public static Cliente buscarPorCodigo(int codCliente) {
		
		Cliente c = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM cliente WHERE codCliente = ?";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, codCliente);
			
			ResultSet rs = stmt.executeQuery(sql);

			if(rs.next()){
				c = new Cliente();
				c.setNome(rs.getString("nome"));
				c.setTelefone(rs.getString("telefone"));
				c.setEmail(rs.getString("email"));
				c.setSexo(rs.getString("telefone"));
				c.setCpf(rs.getString("cpf"));
				c.setRg(rs.getString("rg"));
				c.setSituacao(rs.getString("situacao"));
				c.setNascimento(rs.getDate("nascimento"));
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return c;
	}
	
	public static List<Cliente> buscarPorNome(String nome) {
		
		List<Cliente> lista = new LinkedList<>();
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM cliente WHERE nome = LIKE '%?%' ";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery(sql);

			while(rs.next()){
				Cliente c = new Cliente();
				c.setCodigoCliente(rs.getInt("codCliente"));
				c.setNome(rs.getString("nome"));
				c.setTelefone(rs.getString("telefone"));
				c.setEmail(rs.getString("email"));
				c.setSexo(rs.getString("telefone"));
				c.setCpf(rs.getString("cpf"));
				c.setRg(rs.getString("rg"));
				c.setSituacao(rs.getString("situacao"));
				c.setNascimento(rs.getDate("nascimento"));
				
				lista.add(c);
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return lista;
	}
	
	public static Cliente buscarPorCpf(String cpf) {
		
		Cliente c = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM cliente WHERE cpf = ?";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, cpf);
			
			ResultSet rs = stmt.executeQuery(sql);

			if(rs.next()){
				c = new Cliente();
				c.setNome(rs.getString("nome"));
				c.setTelefone(rs.getString("telefone"));
				c.setEmail(rs.getString("email"));
				c.setSexo(rs.getString("telefone"));
				c.setCpf(rs.getString("cpf"));
				c.setRg(rs.getString("rg"));
				c.setSituacao(rs.getString("situacao"));
				c.setNascimento(rs.getDate("nascimento"));
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return c;
	}
	
	public static boolean excluirCliente(int codigoCliente){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "DELETE FROM cliente WHERE codCliente = ? LIMIT 1";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, codigoCliente);
			
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static boolean atualizarCliente(String nome, String telefone, String email, String sexo, String cpf, String rg, String situacao, String nascimento, int codCliente){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "UPDATE cliente set nome = ?, telefone = ?, email = ?, sexo = ?, cpf = ?, rg = ?, situacao = ?, nascimento = ? WHERE codCliente = ?";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			stmt.setString(2, telefone);
			stmt.setString(3, email);
			stmt.setString(4, sexo);
			stmt.setString(5, cpf);
			stmt.setString(6, rg);
			stmt.setString(7, situacao);
			stmt.setString(8, nascimento);
			stmt.setInt(9, codCliente);
			
			ok = stmt.executeUpdate() > 0;

			con.close();
			stmt.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
}