package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JToolBar;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal telaPrincipal = new TelaPrincipal();
					telaPrincipal.setVisible(true);
					telaPrincipal.setResizable(false);//Impede que a janela seja redimensionada
					telaPrincipal.setLocationRelativeTo(null);//Faz com que a tela aparece centralizada
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setTitle("Tela Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 934, 619);
		
		setExtendedState(MAXIMIZED_BOTH);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnCadastro = new JMenu("Cadastro");
		menuBar.add(mnCadastro);
		
		JMenuItem mntmProduto = new JMenuItem("Produto");
		mntmProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//instancia a tela principal
				Produto produto = new Produto();
				//chama a tela principal
				produto.setVisible(true);
				produto.setLocationRelativeTo(null);//faz a tela aparecer centralizada
			}
		});
		mnCadastro.add(mntmProduto);
		
		JMenuItem mntmCadCliente = new JMenuItem("Cliente");
		mntmCadCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//instancia a tela principal
				Cliente cliente = new Cliente();
				//chama a tela principal
				cliente.setVisible(true);
				cliente.setLocationRelativeTo(null);//faz a tela aparecer centralizada
				
			}
		});
		mnCadastro.add(mntmCadCliente);
		
		JMenuItem mntmCadFuncionario = new JMenuItem("Funcion�rio");
		mntmCadFuncionario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//instancia a tela principal
				CadastroFuncionario cadFucionario = new CadastroFuncionario();
				//chama a tela principal
				cadFucionario.setVisible(true);
				cadFucionario.setLocationRelativeTo(null);//faz a tela aparecer centralizada
				
			}
		});
		mnCadastro.add(mntmCadFuncionario);
		
		JMenuItem mntmCadFornecedores = new JMenuItem("Fornecedores");
		mnCadastro.add(mntmCadFornecedores);
		
		JMenu menuRelatorios = new JMenu("Relat�rios");
		menuBar.add(menuRelatorios);
		
		JMenu menuAjuda = new JMenu("Ajuda");
		menuBar.add(menuAjuda);
		
		JMenu mnSair = new JMenu("Sair");			
		menuBar.add(mnSair);
		
		JMenuItem mntmFinalizarSiatema = new JMenuItem("Finalizar Sistema");
		mntmFinalizarSiatema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				int resposta = JOptionPane.showConfirmDialog(null, "Deseja encerrar o Sistema?",
			    		"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
			    
			    switch(resposta){
			    case JOptionPane.YES_OPTION:
					System.exit(0);
			    	break;
			    case JOptionPane.NO_OPTION:
			    	
					break;
					default:
						break;
			   }
				
			}
		});
		mntmFinalizarSiatema.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/sair24.png")));
		mnSair.add(mntmFinalizarSiatema);
		
		JMenuItem mntmEfetuarLogoff = new JMenuItem("Efetuar Logoff do usu�rio Atual");
		mntmEfetuarLogoff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int resposta = JOptionPane.showConfirmDialog(null, "Tem certeza de que deseja fazer isso?",
			    		"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
			    
			    switch(resposta){
			    case JOptionPane.YES_OPTION:
			    	TelaLogin telaLogin = new TelaLogin();
					telaLogin.setVisible(true);
					telaLogin.setLocationRelativeTo(null);
					dispose();
					
			    	break;
			    case JOptionPane.NO_OPTION:
			    	
					break;
					default:
						break;
			   }
				
			}
		});
		mntmEfetuarLogoff.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/efetuarLogof.png")));
		mnSair.add(mntmEfetuarLogoff);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());
		
		JMenuBar menuBar_1 = new JMenuBar();
		menuBar_1.setBounds(0, 0, 918, 64);
		contentPane.add(menuBar_1, BorderLayout.NORTH);
		
		JButton btnProdutos = new JButton("");
		btnProdutos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Produto produto = new Produto();
				produto.setVisible(true);
				produto.setResizable(false);//n�o deixa o usu�rio redimencionar a janela
				produto.setLocationRelativeTo(null);//faz a tela aparecer centralizada
				
			}
		});
		menuBar_1.add(btnProdutos);
		btnProdutos.setToolTipText("Produtos");
		btnProdutos.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/produto64.png")));
		
		
		//Bot�o de Clientes
		JButton btnClientes = new JButton("");
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Cliente cliente = new Cliente();
				cliente.setVisible(true);
				cliente.setResizable(false);//n�o deixa o usu�rio redimencionar a janela
				cliente.setLocationRelativeTo(null);//faz a tela aparecer centralizada
				
				
			}
		});
		menuBar_1.add(btnClientes);
		btnClientes.setToolTipText("Clientes");
		btnClientes.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/iconCliente64.png")));
		
		JButton btnFuncionarios = new JButton("");
		btnFuncionarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CadastroFuncionario cadFuncionario = new CadastroFuncionario();
				cadFuncionario.setVisible(true);
				//redimencionamento n�o permitido
				cadFuncionario.setResizable(false);
				//Centraliza��o da tela
				cadFuncionario.setLocationRelativeTo(null);
				
				
			}
		});
		btnFuncionarios.setToolTipText("Funcion�rios");
		menuBar_1.add(btnFuncionarios);
		btnFuncionarios.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/iconFuncion\u00E1rio.png")));
		
		JButton btnFornecedor = new JButton("");
		btnFornecedor.setToolTipText("Fornecedor");
		menuBar_1.add(btnFornecedor);
		btnFornecedor.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/iconFornecedor64.png")));
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				BuscaRapida buscaRapida = new BuscaRapida();
				buscaRapida.setVisible(true);
				buscaRapida.setResizable(false);
				buscaRapida.setLocationRelativeTo(null);
				
				
			}
		});
		btnNewButton.setToolTipText("Buscas de Produtos e Clientes");
		menuBar_1.add(btnNewButton);
		btnNewButton.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/pesquisar64.png")));
		
		JButton btnSair = new JButton("");
		btnSair.setToolTipText("Sair");
		menuBar_1.add(btnSair);
		btnSair.setIcon(new ImageIcon(TelaPrincipal.class.getResource("/imagens/sair64.png")));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 
			    int resposta = JOptionPane.showConfirmDialog(null, "Deseja enserrar o sistema?",
			    		"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
			    
			    switch(resposta){
			    case JOptionPane.YES_OPTION:
			    	TelaLogin telaLogin = new TelaLogin();
					telaLogin.setVisible(true);
					telaLogin.setLocationRelativeTo(null);
					dispose();
			    	break;
			    case JOptionPane.NO_OPTION:
			    	
					break;
					default:
						break;
			    }
				
				
				
				
			}
		});
	}
}
