package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;

import util.ManipularImagem;

import javax.swing.JTextPane;
import com.toedter.calendar.JDateChooser;

public class CadastroProduto extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField txtMarca;
	private JTextField txtFornecedor;
	private JTextField txtQuantidade;
	private JTextField txtLote;
	private JTextField txtVencimento;

	
	private BufferedImage imagem;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroProduto cadCliente = new CadastroProduto();
					cadCliente.setVisible(true);
					cadCliente.setResizable(false);
					cadCliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroProduto() {
		setTitle("Cadastro de Produto");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 649, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JLayeredPane layeredPaneInformacpesBasicasDeProduto = new JLayeredPane();
		tabbedPane.addTab("Informa\u00E7\u00F5es b\u00E1sicas do Produto", new ImageIcon(CadastroProduto.class.getResource("/imagens/produto24.png")), layeredPaneInformacpesBasicasDeProduto, null);
		GridBagLayout gbl_layeredPaneInformacpesBasicasDeProduto = new GridBagLayout();
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		layeredPaneInformacpesBasicasDeProduto.setLayout(gbl_layeredPaneInformacpesBasicasDeProduto);
		
		JLabel lblNewLabel = new JLabel("Descri��o do Produto");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		layeredPaneInformacpesBasicasDeProduto.add(lblNewLabel, gbc_lblNewLabel);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 7;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 0;
		gbc_textField.gridy = 1;
		layeredPaneInformacpesBasicasDeProduto.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JLabel lblCodigo = new JLabel("C\u00F3digo");
		GridBagConstraints gbc_lblCodigo = new GridBagConstraints();
		gbc_lblCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_lblCodigo.anchor = GridBagConstraints.WEST;
		gbc_lblCodigo.gridx = 0;
		gbc_lblCodigo.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCodigo, gbc_lblCodigo);
		
		JLabel lblValorCusto = new JLabel("Valor custo");
		GridBagConstraints gbc_lblValorCusto = new GridBagConstraints();
		gbc_lblValorCusto.anchor = GridBagConstraints.WEST;
		gbc_lblValorCusto.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorCusto.gridx = 1;
		gbc_lblValorCusto.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorCusto, gbc_lblValorCusto);
		
		JLabel lblValorVenda = new JLabel("Valor venda");
		GridBagConstraints gbc_lblValorVenda = new GridBagConstraints();
		gbc_lblValorVenda.anchor = GridBagConstraints.WEST;
		gbc_lblValorVenda.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorVenda.gridx = 2;
		gbc_lblValorVenda.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorVenda, gbc_lblValorVenda);
		
		JLabel lblDataDeFabricao = new JLabel("Data de Fabrica��o Dia/M�s/Ano");
		GridBagConstraints gbc_lblDataDeFabricao = new GridBagConstraints();
		gbc_lblDataDeFabricao.anchor = GridBagConstraints.WEST;
		gbc_lblDataDeFabricao.gridwidth = 2;
		gbc_lblDataDeFabricao.insets = new Insets(0, 0, 5, 5);
		gbc_lblDataDeFabricao.gridx = 3;
		gbc_lblDataDeFabricao.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblDataDeFabricao, gbc_lblDataDeFabricao);
		
		JLabel lblCategoria = new JLabel("Categoria");
		GridBagConstraints gbc_lblCategoria = new GridBagConstraints();
		gbc_lblCategoria.anchor = GridBagConstraints.WEST;
		gbc_lblCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_lblCategoria.gridx = 5;
		gbc_lblCategoria.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCategoria, gbc_lblCategoria);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 0;
		gbc_textField_1.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 5);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 1;
		gbc_textField_2.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(textField_2, gbc_textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		GridBagConstraints gbc_textField_3 = new GridBagConstraints();
		gbc_textField_3.insets = new Insets(0, 0, 5, 5);
		gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_3.gridx = 2;
		gbc_textField_3.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(textField_3, gbc_textField_3);
		textField_3.setColumns(10);
		
		
		String[] vetorDia = {"1", "2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17",
				"18","19","20","21","22","23","24","25","26","27","28","29","30","31",};
		
		
		String[] vetorMes = {"1", "2","3","4","5","6","7","8","9","10","11","12"};
		
		JDateChooser dateChooser = new JDateChooser();
		GridBagConstraints gbc_dateChooser = new GridBagConstraints();
		gbc_dateChooser.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooser.fill = GridBagConstraints.HORIZONTAL;
		gbc_dateChooser.gridx = 3;
		gbc_dateChooser.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(dateChooser, gbc_dateChooser);
		
		//String[] categorias = {"A", "B", "C"};
		JComboBox comboBox = new JComboBox();
		//comboBox.addActionListener(event -> {
			//JComboBox cb = (JComboBox) event.getSource();
		//	String conteudo = (String) cb.getSelectedItem();
			//if(cb.getSelectedItem() == null) {
				
		//	}
		//});
		
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 5;
		gbc_comboBox.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(comboBox, gbc_comboBox);
		
		JButton btnNew = new JButton("New");
		GridBagConstraints gbc_btnNew = new GridBagConstraints();
		gbc_btnNew.insets = new Insets(0, 0, 5, 0);
		gbc_btnNew.gridx = 6;
		gbc_btnNew.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(btnNew, gbc_btnNew);
		
		JLabel lblMarca = new JLabel("Marca");
		GridBagConstraints gbc_lblMarca = new GridBagConstraints();
		gbc_lblMarca.anchor = GridBagConstraints.WEST;
		gbc_lblMarca.insets = new Insets(0, 0, 5, 5);
		gbc_lblMarca.gridx = 0;
		gbc_lblMarca.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblMarca, gbc_lblMarca);
		
		JLabel lblFornecedor = new JLabel("Fornecedor");
		GridBagConstraints gbc_lblFornecedor = new GridBagConstraints();
		gbc_lblFornecedor.anchor = GridBagConstraints.WEST;
		gbc_lblFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_lblFornecedor.gridx = 1;
		gbc_lblFornecedor.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblFornecedor, gbc_lblFornecedor);
		
		JLabel lblQuantidade = new JLabel("Quantidade");
		GridBagConstraints gbc_lblQuantidade = new GridBagConstraints();
		gbc_lblQuantidade.anchor = GridBagConstraints.WEST;
		gbc_lblQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_lblQuantidade.gridx = 2;
		gbc_lblQuantidade.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblQuantidade, gbc_lblQuantidade);
		
		JLabel lblLote = new JLabel("Lote");
		GridBagConstraints gbc_lblLote = new GridBagConstraints();
		gbc_lblLote.gridwidth = 2;
		gbc_lblLote.anchor = GridBagConstraints.WEST;
		gbc_lblLote.insets = new Insets(0, 0, 5, 5);
		gbc_lblLote.gridx = 3;
		gbc_lblLote.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblLote, gbc_lblLote);
		
		JLabel lblVencimento = new JLabel("Vencimento");
		GridBagConstraints gbc_lblVencimento = new GridBagConstraints();
		gbc_lblVencimento.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblVencimento.insets = new Insets(0, 0, 5, 5);
		gbc_lblVencimento.gridx = 5;
		gbc_lblVencimento.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblVencimento, gbc_lblVencimento);
		
		txtMarca = new JTextField();
		GridBagConstraints gbc_txtMarca = new GridBagConstraints();
		gbc_txtMarca.insets = new Insets(0, 0, 5, 5);
		gbc_txtMarca.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtMarca.gridx = 0;
		gbc_txtMarca.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtMarca, gbc_txtMarca);
		txtMarca.setColumns(10);
		
		txtFornecedor = new JTextField();
		GridBagConstraints gbc_txtFornecedor = new GridBagConstraints();
		gbc_txtFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_txtFornecedor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFornecedor.gridx = 1;
		gbc_txtFornecedor.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtFornecedor, gbc_txtFornecedor);
		txtFornecedor.setColumns(10);
		
		txtQuantidade = new JTextField();
		GridBagConstraints gbc_txtQuantidade = new GridBagConstraints();
		gbc_txtQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_txtQuantidade.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtQuantidade.gridx = 2;
		gbc_txtQuantidade.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtQuantidade, gbc_txtQuantidade);
		txtQuantidade.setColumns(10);
		
		txtLote = new JTextField();
		GridBagConstraints gbc_txtLote = new GridBagConstraints();
		gbc_txtLote.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLote.gridwidth = 2;
		gbc_txtLote.insets = new Insets(0, 0, 5, 5);
		gbc_txtLote.gridx = 3;
		gbc_txtLote.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtLote, gbc_txtLote);
		txtLote.setColumns(10);
		
		txtVencimento = new JTextField();
		GridBagConstraints gbc_txtVencimento = new GridBagConstraints();
		gbc_txtVencimento.gridwidth = 2;
		gbc_txtVencimento.insets = new Insets(0, 0, 5, 5);
		gbc_txtVencimento.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtVencimento.gridx = 5;
		gbc_txtVencimento.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtVencimento, gbc_txtVencimento);
		txtVencimento.setColumns(10);
		
		JLabel lblInformaes = new JLabel("Informa��es adicinionais:");
		GridBagConstraints gbc_lblInformaes = new GridBagConstraints();
		gbc_lblInformaes.anchor = GridBagConstraints.WEST;
		gbc_lblInformaes.gridwidth = 2;
		gbc_lblInformaes.insets = new Insets(0, 0, 5, 5);
		gbc_lblInformaes.gridx = 0;
		gbc_lblInformaes.gridy = 6;
		layeredPaneInformacpesBasicasDeProduto.add(lblInformaes, gbc_lblInformaes);
		
		JTextArea textAreaIformacoesAdicionais = new JTextArea();
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.insets = new Insets(0, 0, 0, 5);
		gbc_textArea.gridwidth = 7;
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 0;
		gbc_textArea.gridy = 7;
		
		//pular de linha quando n�o couber mais na linha
		textAreaIformacoesAdicionais.setLineWrap(true);
						 //descer com a palavra quando ela n�o couber mais na linha
		textAreaIformacoesAdicionais.setWrapStyleWord(true);
						JScrollPane sp = new JScrollPane(textAreaIformacoesAdicionais, 
								 JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
								 JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		layeredPaneInformacpesBasicasDeProduto.add(sp, gbc_textArea);
		
		JLayeredPane layeredPaneObservcoesEFoto = new JLayeredPane();
		tabbedPane.addTab("Observa��es e foto", null, layeredPaneObservcoesEFoto, null);
		GridBagLayout gbl_layeredPaneObservcoesEFoto = new GridBagLayout();
		gbl_layeredPaneObservcoesEFoto.columnWidths = new int[]{0, 0, 0};
		gbl_layeredPaneObservcoesEFoto.rowHeights = new int[]{0, 0};
		gbl_layeredPaneObservcoesEFoto.columnWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		gbl_layeredPaneObservcoesEFoto.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		layeredPaneObservcoesEFoto.setLayout(gbl_layeredPaneObservcoesEFoto);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 0, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		layeredPaneObservcoesEFoto.add(panel_1, gbc_panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JLabel lblNew = new JLabel("FOTO DO PRODUTO:");
		GridBagConstraints gbc_lblNew = new GridBagConstraints();
		gbc_lblNew.gridwidth = 2;
		gbc_lblNew.insets = new Insets(0, 0, 5, 0);
		gbc_lblNew.gridx = 0;
		gbc_lblNew.gridy = 0;
		panel_1.add(lblNew, gbc_lblNew);
		
		JLabel lblImagem = new JLabel("");
		lblImagem.setToolTipText("Adicione uma imagem");
		lblImagem.setBackground(Color.WHITE);
		GridBagConstraints gbc_lblImagem = new GridBagConstraints();
		gbc_lblImagem.gridwidth = 2;
		gbc_lblImagem.insets = new Insets(0, 0, 5, 5);
		gbc_lblImagem.gridx = 0;
		gbc_lblImagem.gridy = 1;
		panel_1.add(lblImagem, gbc_lblImagem);
		
		JButton btnNewButton = new JButton("Adicinar Imagem");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				  JFileChooser fc = new JFileChooser();
			        int res = fc.showOpenDialog(null);
			        
			        if (res == JFileChooser.APPROVE_OPTION) {
			            File arquivo = fc.getSelectedFile();
			            
			            try {
			                imagem = ManipularImagem.setImagemDimensao(arquivo.getAbsolutePath(), 260, 260);
			                
			                lblImagem.setIcon(new ImageIcon(imagem));

			            } catch (Exception ex) {
			               // System.out.println(ex.printStackTrace().toString());
			            }

			        } else {
			            JOptionPane.showMessageDialog(null, "Voce nao selecionou nenhum arquivo.");
			        }	
			        
			        			
			}
		});
		btnNewButton.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/addImagem24.png")));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 2;
		panel_1.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//lblImagem.setText(""); 
				
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/limpar24.png")));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.anchor = GridBagConstraints.EAST;
		gbc_btnNewButton_1.gridx = 1;
		gbc_btnNewButton_1.gridy = 2;
		panel_1.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.fill = GridBagConstraints.BOTH;
		gbc_panel_2.gridx = 1;
		gbc_panel_2.gridy = 0;
		layeredPaneObservcoesEFoto.add(panel_2, gbc_panel_2);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[]{0, 0, 0};
		gbl_panel_2.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel_2.columnWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_2.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_2.setLayout(gbl_panel_2);
		
		JLabel lblNew_1 = new JLabel("Observa��es:");
		GridBagConstraints gbc_lblNew_1 = new GridBagConstraints();
		gbc_lblNew_1.gridwidth = 2;
		gbc_lblNew_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNew_1.gridx = 0;
		gbc_lblNew_1.gridy = 0;
		panel_2.add(lblNew_1, gbc_lblNew_1);
		
		
		
		JTextArea textAreaObservacoesDoProduto = new JTextArea();
		GridBagConstraints gbc_textAreaObservacoesDoProduto = new GridBagConstraints();
		gbc_textAreaObservacoesDoProduto.gridwidth = 2;
		gbc_textAreaObservacoesDoProduto.insets = new Insets(0, 0, 5, 5);
		gbc_textAreaObservacoesDoProduto.fill = GridBagConstraints.BOTH;
		gbc_textAreaObservacoesDoProduto.gridx = 0;
		gbc_textAreaObservacoesDoProduto.gridy = 1;
		//pular de linha quando n�o couber mais na linha
		textAreaObservacoesDoProduto.setLineWrap(true);
		 //descer com a palavra quando ela n�o couber mais na linha
		textAreaObservacoesDoProduto.setWrapStyleWord(true);
		JScrollPane sp2 = new JScrollPane(textAreaObservacoesDoProduto, 
				 JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
				 JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		panel_2.add(sp2, gbc_textAreaObservacoesDoProduto);
		
		
		
		
		
		JButton btnApagarTexto = new JButton("Apagar Texto");
		GridBagConstraints gbc_btnApagarTexto = new GridBagConstraints();
		gbc_btnApagarTexto.anchor = GridBagConstraints.WEST;
		gbc_btnApagarTexto.insets = new Insets(0, 0, 0, 5);
		gbc_btnApagarTexto.gridx = 0;
		gbc_btnApagarTexto.gridy = 2;
		panel_2.add(btnApagarTexto, gbc_btnApagarTexto);
		
		JButton btnSalavrTexto = new JButton("Salvar Texto");
		GridBagConstraints gbc_btnSalavrTexto = new GridBagConstraints();
		gbc_btnSalavrTexto.anchor = GridBagConstraints.EAST;
		gbc_btnSalavrTexto.gridx = 1;
		gbc_btnSalavrTexto.gridy = 2;
		panel_2.add(btnSalavrTexto, gbc_btnSalavrTexto);
		
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.anchor = GridBagConstraints.SOUTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnSalvar = new JButton("Salvar (F2)");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			
				
			}
		});
		btnSalvar.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnSalvar.insets = new Insets(0, 0, 5, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 0;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JButton btnFechar = new JButton("Fechar (ESC)");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int resposta = JOptionPane.showConfirmDialog(null,
						"Tem certeza de que quer fechar a janela e perder todo o Conte�do?", 
						"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
				
				switch(resposta){
				case JOptionPane.YES_OPTION:
					dispose();

					break;
				case JOptionPane.NO_OPTION:
					
				}
				
			}
		});
		btnFechar.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/fechar32.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnFechar.insets = new Insets(0, 0, 5, 0);
		gbc_btnFechar.gridx = 6;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);
	}
}
