package view.TM;

import javax.swing.table.AbstractTableModel;

public class TabelaProduto extends AbstractTableModel{
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		
		
		return 11;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		
		
		//retorna a quantidade de registro do banco
		//return this.contatos.size();
		return 0;
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		
		
		return null;
	}

}
