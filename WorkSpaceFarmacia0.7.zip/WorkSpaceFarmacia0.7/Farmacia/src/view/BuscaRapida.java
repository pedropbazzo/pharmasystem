package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.UIManager;
import java.awt.Color;

public class BuscaRapida extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable tabelaListaDeProduto;
	private JTextField txtPesquisarPorNome;
	private JTextField txtCodigo;
	private JTable tabelaListaDeCliente;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscaRapida buscaRapida = new BuscaRapida();
					buscaRapida.setVisible(true);
					buscaRapida.setResizable(false);
					buscaRapida.setLocationRelativeTo(null);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscaRapida() {
		setTitle("Busca R�pida");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 667, 542);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 16;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);

		JLayeredPane layeredPanePesquisarProduto = new JLayeredPane();
		layeredPanePesquisarProduto.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
				"Modos de Busca:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		tabbedPane.addTab("Pesquisar Produto", null, layeredPanePesquisarProduto, null);
		GridBagLayout gbl_layeredPanePesquisarProduto = new GridBagLayout();
		gbl_layeredPanePesquisarProduto.columnWidths = new int[] { 0, 0, 0, 0 };
		gbl_layeredPanePesquisarProduto.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0 };
		gbl_layeredPanePesquisarProduto.columnWeights = new double[] { 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_layeredPanePesquisarProduto.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		layeredPanePesquisarProduto.setLayout(gbl_layeredPanePesquisarProduto);

		JLabel label_2 = new JLabel("Digite o Nome e precione Enter para localizar:");
		GridBagConstraints gbc_label_2 = new GridBagConstraints();
		gbc_label_2.anchor = GridBagConstraints.WEST;
		gbc_label_2.insets = new Insets(0, 0, 5, 5);
		gbc_label_2.gridx = 0;
		gbc_label_2.gridy = 1;
		layeredPanePesquisarProduto.add(label_2, gbc_label_2);

		JLabel label_3 = new JLabel("C\u00F3digo:");
		GridBagConstraints gbc_label_3 = new GridBagConstraints();
		gbc_label_3.anchor = GridBagConstraints.WEST;
		gbc_label_3.insets = new Insets(0, 0, 5, 5);
		gbc_label_3.gridx = 1;
		gbc_label_3.gridy = 1;
		layeredPanePesquisarProduto.add(label_3, gbc_label_3);

		JLabel label_4 = new JLabel("Fornecedor:");
		GridBagConstraints gbc_label_4 = new GridBagConstraints();
		gbc_label_4.anchor = GridBagConstraints.WEST;
		gbc_label_4.insets = new Insets(0, 0, 5, 0);
		gbc_label_4.gridx = 2;
		gbc_label_4.gridy = 1;
		layeredPanePesquisarProduto.add(label_4, gbc_label_4);

		textField = new JTextField();
		textField.setColumns(10);
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 0;
		gbc_textField.gridy = 2;
		layeredPanePesquisarProduto.add(textField, gbc_textField);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 1;
		gbc_textField_1.gridy = 2;
		layeredPanePesquisarProduto.add(textField_1, gbc_textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 0);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 2;
		gbc_textField_2.gridy = 2;
		layeredPanePesquisarProduto.add(textField_2, gbc_textField_2);

		JButton button = new JButton("Localizar (ENTER)");
		button.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 0);
		gbc_button.gridx = 2;
		gbc_button.gridy = 3;
		layeredPanePesquisarProduto.add(button, gbc_button);

		tabelaListaDeProduto = new JTable();
		GridBagConstraints gbc_tabelaListaDeProduto = new GridBagConstraints();
		gbc_tabelaListaDeProduto.gridheight = 2;
		gbc_tabelaListaDeProduto.gridwidth = 3;
		gbc_tabelaListaDeProduto.fill = GridBagConstraints.BOTH;
		gbc_tabelaListaDeProduto.gridx = 0;
		gbc_tabelaListaDeProduto.gridy = 4;
		layeredPanePesquisarProduto.add(tabelaListaDeProduto, gbc_tabelaListaDeProduto);

		JLayeredPane layeredPanePesquisarCliente = new JLayeredPane();
		layeredPanePesquisarCliente.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
				"Modos de Busca:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		tabbedPane.addTab("Pesquisar Cliente", null, layeredPanePesquisarCliente, null);
		GridBagLayout gbl_layeredPanePesquisarCliente = new GridBagLayout();
		gbl_layeredPanePesquisarCliente.columnWidths = new int[] { 0, 0, 0, 0 };
		gbl_layeredPanePesquisarCliente.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0 };
		gbl_layeredPanePesquisarCliente.columnWeights = new double[] { 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_layeredPanePesquisarCliente.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		layeredPanePesquisarCliente.setLayout(gbl_layeredPanePesquisarCliente);

		JLabel lblPesquisarPorNome = new JLabel("Digite o Nome e precione Enter para localizar:");
		GridBagConstraints gbc_lblPesquisarPorNome = new GridBagConstraints();
		gbc_lblPesquisarPorNome.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPorNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPorNome.gridx = 0;
		gbc_lblPesquisarPorNome.gridy = 1;
		layeredPanePesquisarCliente.add(lblPesquisarPorNome, gbc_lblPesquisarPorNome);

		JLabel lblCodigo = new JLabel("C�digo:");
		GridBagConstraints gbc_lblCodigo = new GridBagConstraints();
		gbc_lblCodigo.anchor = GridBagConstraints.WEST;
		gbc_lblCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_lblCodigo.gridx = 1;
		gbc_lblCodigo.gridy = 1;
		layeredPanePesquisarCliente.add(lblCodigo, gbc_lblCodigo);

		txtPesquisarPorNome = new JTextField();
		txtPesquisarPorNome.setColumns(10);
		GridBagConstraints gbc_txtPesquisarPorNome = new GridBagConstraints();
		gbc_txtPesquisarPorNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPesquisarPorNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtPesquisarPorNome.gridx = 0;
		gbc_txtPesquisarPorNome.gridy = 2;
		layeredPanePesquisarCliente.add(txtPesquisarPorNome, gbc_txtPesquisarPorNome);

		txtCodigo = new JTextField();
		txtCodigo.setColumns(10);
		GridBagConstraints gbc_txtCodigo = new GridBagConstraints();
		gbc_txtCodigo.gridwidth = 2;
		gbc_txtCodigo.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigo.gridx = 1;
		gbc_txtCodigo.gridy = 2;
		layeredPanePesquisarCliente.add(txtCodigo, gbc_txtCodigo);

		JButton btnNewButton = new JButton("Localizar (ENTER)");
		btnNewButton.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.gridwidth = 2;
		gbc_btnNewButton.fill = GridBagConstraints.BOTH;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 1;
		gbc_btnNewButton.gridy = 3;
		layeredPanePesquisarCliente.add(btnNewButton, gbc_btnNewButton);

		tabelaListaDeCliente = new JTable();
		GridBagConstraints gbc_tabelaListaDeCliente = new GridBagConstraints();
		gbc_tabelaListaDeCliente.fill = GridBagConstraints.BOTH;
		gbc_tabelaListaDeCliente.gridheight = 2;
		gbc_tabelaListaDeCliente.gridwidth = 3;
		gbc_tabelaListaDeCliente.gridx = 0;
		gbc_tabelaListaDeCliente.gridy = 4;
		layeredPanePesquisarCliente.add(tabelaListaDeCliente, gbc_tabelaListaDeCliente);

		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.anchor = GridBagConstraints.SOUTH;
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 16;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 0, 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JLabel lblProdutosListador = new JLabel("Produtos Listados:");

		GridBagConstraints gbc_lblProdutosListador = new GridBagConstraints();
		gbc_lblProdutosListador.insets = new Insets(0, 0, 5, 5);
		gbc_lblProdutosListador.gridx = 0;
		gbc_lblProdutosListador.gridy = 0;
		panel.add(lblProdutosListador, gbc_lblProdutosListador);

		lblProdutosListador.setText("Produtos Listados:");

		JButton btnCadastrarProduto = new JButton("Cadastrar Produto");
		btnCadastrarProduto.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/produto24.png")));

		btnCadastrarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroProduto cadProduto = new CadastroProduto();
				cadProduto.setVisible(true);
				cadProduto.setResizable(false);
				cadProduto.setLocationRelativeTo(null);
			}
		});

		GridBagConstraints gbc_btnCadastrarProduto = new GridBagConstraints();
		gbc_btnCadastrarProduto.gridheight = 2;
		gbc_btnCadastrarProduto.anchor = GridBagConstraints.EAST;
		gbc_btnCadastrarProduto.insets = new Insets(0, 0, 5, 5);
		gbc_btnCadastrarProduto.gridx = 1;
		gbc_btnCadastrarProduto.gridy = 0;

		JButton btnCadastrarCliente = new JButton("Cadastrar Cliente");
		btnCadastrarCliente.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/iconCliente24.png")));

		btnCadastrarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroCliente cadCliente = new CadastroCliente();
				cadCliente.setVisible(true);
				cadCliente.setResizable(false);
				cadCliente.setLocationRelativeTo(null);
			}
		});

		GridBagConstraints gbc_btnCadastrarCliente = new GridBagConstraints();
		gbc_btnCadastrarCliente.gridheight = 2;
		gbc_btnCadastrarCliente.anchor = GridBagConstraints.EAST;
		gbc_btnCadastrarCliente.insets = new Insets(0, 0, 5, 5);
		gbc_btnCadastrarCliente.gridx = 1;
		gbc_btnCadastrarCliente.gridy = 0;

		panel.add(btnCadastrarProduto, gbc_btnCadastrarProduto);
		panel.add(btnCadastrarCliente, gbc_btnCadastrarCliente);
		btnCadastrarCliente.setVisible(false);
		
		tabbedPane.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				if(tabbedPane.getSelectedIndex() == 0) {
					
					btnCadastrarProduto.setVisible(true);
					btnCadastrarCliente.setVisible(false);
					
				} else if(tabbedPane.getSelectedIndex() == 1) {
					
					btnCadastrarProduto.setVisible(false);
					btnCadastrarCliente.setVisible(true);
					
				}
			}
		});



		JButton btnEditar = new JButton("Editar");
		btnEditar.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditar = new GridBagConstraints();
		gbc_btnEditar.gridheight = 2;
		gbc_btnEditar.anchor = GridBagConstraints.EAST;
		gbc_btnEditar.insets = new Insets(0, 0, 5, 5);
		gbc_btnEditar.gridx = 2;
		gbc_btnEditar.gridy = 0;
		panel.add(btnEditar, gbc_btnEditar);

		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();

			}
		});
		btnFechar.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/fechar.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.gridheight = 2;
		gbc_btnFechar.insets = new Insets(0, 0, 5, 0);
		gbc_btnFechar.anchor = GridBagConstraints.EAST;
		gbc_btnFechar.gridx = 3;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);

		JLabel label = new JLabel("0");
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.anchor = GridBagConstraints.WEST;
		gbc_label.insets = new Insets(0, 0, 0, 5);
		gbc_label.gridx = 0;
		gbc_label.gridy = 1;
		panel.add(label, gbc_label);

	}

}
