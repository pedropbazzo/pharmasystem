package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.JSeparator;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JRadioButton;
import javax.swing.Icon;
import javax.swing.border.TitledBorder;

public class Produto extends JFrame {

	private JPanel contentPane;
	private JTextField txtPesquisarPorNome;
	private JTable table;
	
	//String para aparecer quando o usu�rio selecionar o RadioButton
	String opcaoNome = "Pesquisar produto j� cadastrado por [Nome]:";
	String opcaoFornecedor = "Pesquisar produto j� cadastrado por [Fornecedor]:";
	String opcaoCodigo = "Pesquisar produto j� cadastrado por [C�digo]:";

	JLabel lblPesquisarPor = new JLabel(opcaoNome);
	GridBagConstraints gbc_lblPesquisarPor = new GridBagConstraints();
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Produto cliente = new Produto();
					cliente.setVisible(true);
					cliente.setResizable(false);
					cliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Produto() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 777, 532);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{815, 0};
		gbl_contentPane.rowHeights = new int[]{14, 289, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblCliente = new JLabel("Produto");
		GridBagConstraints gbc_lblCliente = new GridBagConstraints();
		gbc_lblCliente.anchor = GridBagConstraints.NORTH;
		gbc_lblCliente.insets = new Insets(0, 0, 5, 0);
		gbc_lblCliente.gridx = 0;
		gbc_lblCliente.gridy = 0;
		contentPane.add(lblCliente, gbc_lblCliente);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		
		JLayeredPane layeredPaneListaDeCliente = new JLayeredPane();
		layeredPaneListaDeCliente.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tabbedPane.addTab("Lista dos Produtos", null, layeredPaneListaDeCliente, null);
		GridBagLayout gbl_layeredPaneListaDeCliente = new GridBagLayout();
		gbl_layeredPaneListaDeCliente.columnWidths = new int[]{0, 0};
		gbl_layeredPaneListaDeCliente.rowHeights = new int[]{0, 0};
		gbl_layeredPaneListaDeCliente.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_layeredPaneListaDeCliente.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		layeredPaneListaDeCliente.setLayout(gbl_layeredPaneListaDeCliente);
		
		table = new JTable();
		GridBagConstraints gbc_table = new GridBagConstraints();
		gbc_table.fill = GridBagConstraints.BOTH;
		gbc_table.gridx = 0;
		gbc_table.gridy = 0;
		
		
		layeredPaneListaDeCliente.add(table, gbc_table);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 6;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridheight = 3;
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 7;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		
		//local da label Pesquisar produto por
		gbc_lblPesquisarPor.gridwidth = 3;
		gbc_lblPesquisarPor.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPor.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPor.gridx = 0;
		gbc_lblPesquisarPor.gridy = 0;
		panel.add(lblPesquisarPor, gbc_lblPesquisarPor);
		
		txtPesquisarPorNome = new JTextField();
		GridBagConstraints gbc_txtPesquisarPorNome = new GridBagConstraints();
		gbc_txtPesquisarPorNome.gridwidth = 5;
		gbc_txtPesquisarPorNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtPesquisarPorNome.fill = GridBagConstraints.BOTH;
		gbc_txtPesquisarPorNome.gridx = 0;
		gbc_txtPesquisarPorNome.gridy = 1;
		panel.add(txtPesquisarPorNome, gbc_txtPesquisarPorNome);
		txtPesquisarPorNome.setColumns(10);
		
		
		
		//=======================================================================
		
		JButton btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				CadastroProduto cadProduto = new CadastroProduto();
				cadProduto.setVisible(true);
				cadProduto.setResizable(false);
				cadProduto.setLocationRelativeTo(null);
				
			}
		});
		
		JPanel painelMudosDePesquisas = new JPanel(new GridLayout(2, 1));
		painelMudosDePesquisas.setBorder(new TitledBorder(null, "Modos de pesquisas dispon\u00EDveis:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GridBagConstraints gbc_painelMudosDePesquisas = new GridBagConstraints();
		gbc_painelMudosDePesquisas.gridwidth = 2;
		gbc_painelMudosDePesquisas.gridheight = 3;
		gbc_painelMudosDePesquisas.insets = new Insets(0, 0, 5, 5);
		gbc_painelMudosDePesquisas.fill = GridBagConstraints.BOTH;
		gbc_painelMudosDePesquisas.gridx = 5;
		gbc_painelMudosDePesquisas.gridy = 0;
		panel.add(painelMudosDePesquisas, gbc_painelMudosDePesquisas);
		
		JRadioButton radioButtonNome = new JRadioButton("Nome");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�Nome�
		radioButtonNome.setActionCommand("Nome");
		radioButtonNome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoNome);
				
			}
		});
		radioButtonNome.setSelected(true);
		painelMudosDePesquisas.add(radioButtonNome);
		
		JRadioButton radioButtonFornecedor = new JRadioButton("Fornecedor");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�Fornecedor�
		radioButtonFornecedor.setActionCommand("Fornecedor");
		radioButtonFornecedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoFornecedor);
				
			}
		});
		painelMudosDePesquisas.add(radioButtonFornecedor);
		
		JRadioButton radioButtonCodigo = new JRadioButton("C�digo");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�C�digo�
		radioButtonCodigo.setActionCommand("C�digo");

		radioButtonCodigo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoCodigo);
				
			}
		});
		painelMudosDePesquisas.add(radioButtonCodigo);
		
		ButtonGroup grupo = new ButtonGroup();
		grupo.add(radioButtonNome);
		grupo.add(radioButtonFornecedor);
		grupo.add(radioButtonCodigo);
		
		
		btnNovo.setIcon(new ImageIcon(Produto.class.getResource("/imagens/novo2.png")));
		GridBagConstraints gbc_btnNovo = new GridBagConstraints();
		gbc_btnNovo.insets = new Insets(0, 0, 0, 5);
		gbc_btnNovo.fill = GridBagConstraints.VERTICAL;
		gbc_btnNovo.anchor = GridBagConstraints.WEST;
		gbc_btnNovo.gridx = 0;
		gbc_btnNovo.gridy = 2;
		panel.add(btnNovo, gbc_btnNovo);
		
		JButton btnApagar = new JButton("Apagar");
		btnApagar.setIcon(new ImageIcon(Produto.class.getResource("/imagens/Apagar.png")));
		GridBagConstraints gbc_btnApagar = new GridBagConstraints();
		gbc_btnApagar.insets = new Insets(0, 0, 0, 5);
		gbc_btnApagar.gridx = 1;
		gbc_btnApagar.gridy = 2;
		panel.add(btnApagar, gbc_btnApagar);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.setIcon(new ImageIcon(Produto.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditar = new GridBagConstraints();
		gbc_btnEditar.insets = new Insets(0, 0, 0, 5);
		gbc_btnEditar.gridx = 2;
		gbc_btnEditar.gridy = 2;
		panel.add(btnEditar, gbc_btnEditar);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/*String comando = grupo.getSelection().getActionCommand();
				JButton b = (JButton)e.getSource();
				JOptionPane.showMessageDialog(b.getParent(), comando);*/
				
				
				
				
				
			}
		});
		btnPesquisar.setIcon(new ImageIcon(Produto.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnPesquisar = new GridBagConstraints();
		gbc_btnPesquisar.insets = new Insets(0, 0, 0, 5);
		gbc_btnPesquisar.gridx = 3;
		gbc_btnPesquisar.gridy = 2;
		panel.add(btnPesquisar, gbc_btnPesquisar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
			}
		});
		btnFechar.setIcon(new ImageIcon(Produto.class.getResource("/imagens/fechar.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.insets = new Insets(0, 0, 0, 5);
		gbc_btnFechar.gridx = 4;
		gbc_btnFechar.gridy = 2;
		panel.add(btnFechar, gbc_btnFechar);
		
		
		
		
		
	}
}
