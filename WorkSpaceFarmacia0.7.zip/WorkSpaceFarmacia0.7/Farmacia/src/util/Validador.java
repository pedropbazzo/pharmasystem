package util;

public interface Validador {
	
	boolean validarLogin(String login, String senha);

}