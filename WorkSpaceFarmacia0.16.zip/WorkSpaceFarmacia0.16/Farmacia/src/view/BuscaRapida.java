package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.MaskFormatter;

import model.Cliente;
import model.Endereco;
import model.Produto;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.ProdutoDAO;
import view.TM.TabelaClienteBuscaRapida;
import view.TM.TabelaProduto;
import view.TM.TabelaProdutoBuscaRapida;

import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFormattedTextField;

public class BuscaRapida extends JFrame {

	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtCodigoBarra;
	private JTextField txtFornecedor;
	private JFormattedTextField formattedTextFieldCpfCliente;
	
	private JTable tabelaProduto;
	private JTable tabelaCliente;
	
	JLabel lblQuantidadeProdutosListados;
	JLabel lblQuantidadeClienteListados;

	int codProduto;
	int codCliente;

	int produtosListados;
	int clientesListados;
	private JTextField txtNomeCliente;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscaRapida buscaRapida = new BuscaRapida();
					buscaRapida.setVisible(true);
					buscaRapida.setResizable(false);
					buscaRapida.setLocationRelativeTo(null);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscaRapida() {
		setTitle("Busca R�pida");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 667, 542);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 0, 0 };
		gbl_contentPane.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 1.0, 1.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 16;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);

		JLayeredPane layeredPanePesquisarProduto = new JLayeredPane();
		layeredPanePesquisarProduto.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
				"Modos de Busca:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		tabbedPane.addTab("Pesquisar Produto", null, layeredPanePesquisarProduto, null);
		GridBagLayout gbl_layeredPanePesquisarProduto = new GridBagLayout();
		gbl_layeredPanePesquisarProduto.columnWidths = new int[] { 0, 0, 0, 0 };
		gbl_layeredPanePesquisarProduto.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0 };
		gbl_layeredPanePesquisarProduto.columnWeights = new double[] { 1.0, 1.0, 0.0, Double.MIN_VALUE };
		gbl_layeredPanePesquisarProduto.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		layeredPanePesquisarProduto.setLayout(gbl_layeredPanePesquisarProduto);

		JLabel lblPesquisarPorNomeProduto = new JLabel("Digite o nome e pressione Enter para localizar:");
		GridBagConstraints gbc_lblPesquisarPorNomeProduto = new GridBagConstraints();
		gbc_lblPesquisarPorNomeProduto.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPorNomeProduto.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPorNomeProduto.gridx = 0;
		gbc_lblPesquisarPorNomeProduto.gridy = 1;
		layeredPanePesquisarProduto.add(lblPesquisarPorNomeProduto, gbc_lblPesquisarPorNomeProduto);

		JLabel lblCodigoBarro = new JLabel("C\u00F3digo de Barra:");
		GridBagConstraints gbc_lblCodigoBarro = new GridBagConstraints();
		gbc_lblCodigoBarro.anchor = GridBagConstraints.WEST;
		gbc_lblCodigoBarro.insets = new Insets(0, 0, 5, 5);
		gbc_lblCodigoBarro.gridx = 1;
		gbc_lblCodigoBarro.gridy = 1;
		layeredPanePesquisarProduto.add(lblCodigoBarro, gbc_lblCodigoBarro);

		JLabel lblFornecedor = new JLabel("Fornecedor:");
		GridBagConstraints gbc_lblFornecedor = new GridBagConstraints();
		gbc_lblFornecedor.anchor = GridBagConstraints.WEST;
		gbc_lblFornecedor.insets = new Insets(0, 0, 5, 0);
		gbc_lblFornecedor.gridx = 2;
		gbc_lblFornecedor.gridy = 1;
		layeredPanePesquisarProduto.add(lblFornecedor, gbc_lblFornecedor);

		txtNome = new JTextField();
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtNome.setText(txtNome.getText().toUpperCase());
			}
		});
		txtNome.setColumns(10);
		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 2;
		layeredPanePesquisarProduto.add(txtNome, gbc_txtNome);

		txtCodigoBarra = new JTextField();
		txtCodigoBarra.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtCodigoBarra.setText(txtCodigoBarra.getText().replaceAll("[^0-9]", ""));
			
			}
		});
		txtCodigoBarra.setColumns(10);
		GridBagConstraints gbc_txtCodigoBarra = new GridBagConstraints();
		gbc_txtCodigoBarra.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigoBarra.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigoBarra.gridx = 1;
		gbc_txtCodigoBarra.gridy = 2;
		layeredPanePesquisarProduto.add(txtCodigoBarra, gbc_txtCodigoBarra);

		txtFornecedor = new JTextField();
		txtFornecedor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtFornecedor.setText(txtFornecedor.getText().toUpperCase());
				
			}
		});
		txtFornecedor.setColumns(10);
		GridBagConstraints gbc_txtFornecedor = new GridBagConstraints();
		gbc_txtFornecedor.insets = new Insets(0, 0, 5, 0);
		gbc_txtFornecedor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFornecedor.gridx = 2;
		gbc_txtFornecedor.gridy = 2;
		layeredPanePesquisarProduto.add(txtFornecedor, gbc_txtFornecedor);

	

		JScrollPane scrollPaneProduto = new JScrollPane();
		GridBagConstraints gbc_scrollPaneProduto = new GridBagConstraints();
		gbc_scrollPaneProduto.gridheight = 2;
		gbc_scrollPaneProduto.gridwidth = 3;
		gbc_scrollPaneProduto.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPaneProduto.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneProduto.gridx = 0;
		gbc_scrollPaneProduto.gridy = 4;
		layeredPanePesquisarProduto.add(scrollPaneProduto, gbc_scrollPaneProduto);

		JLayeredPane layeredPanePesquisarCliente = new JLayeredPane();
		layeredPanePesquisarCliente.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
				"Modos de Busca:", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		tabbedPane.addTab("Pesquisar Cliente", null, layeredPanePesquisarCliente, null);
		GridBagLayout gbl_layeredPanePesquisarCliente = new GridBagLayout();
		gbl_layeredPanePesquisarCliente.columnWidths = new int[] { 0, 0, 0, 0 };
		gbl_layeredPanePesquisarCliente.rowHeights = new int[] { 0, 0, 0, 0, 0, 0 };
		gbl_layeredPanePesquisarCliente.columnWeights = new double[] { 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_layeredPanePesquisarCliente.rowWeights = new double[] { 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		layeredPanePesquisarCliente.setLayout(gbl_layeredPanePesquisarCliente);

		JLabel lblPesquisarPorNomeCliente = new JLabel("Digite o nome e pressione Enter para localizar:");
		GridBagConstraints gbc_lblPesquisarPorNomeCliente = new GridBagConstraints();
		gbc_lblPesquisarPorNomeCliente.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPorNomeCliente.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPorNomeCliente.gridx = 0;
		gbc_lblPesquisarPorNomeCliente.gridy = 0;
		layeredPanePesquisarCliente.add(lblPesquisarPorNomeCliente, gbc_lblPesquisarPorNomeCliente);

		JLabel lblCpf = new JLabel("CPF:");
		GridBagConstraints gbc_lblCpf = new GridBagConstraints();
		gbc_lblCpf.anchor = GridBagConstraints.WEST;
		gbc_lblCpf.insets = new Insets(0, 0, 5, 5);
		gbc_lblCpf.gridx = 1;
		gbc_lblCpf.gridy = 0;
		layeredPanePesquisarCliente.add(lblCpf, gbc_lblCpf);
		
		txtNomeCliente = new JTextField();
		txtNomeCliente.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				
				txtNomeCliente.setText(txtNomeCliente.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtNomeCliente = new GridBagConstraints();
		gbc_txtNomeCliente.insets = new Insets(0, 0, 5, 5);
		gbc_txtNomeCliente.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNomeCliente.gridx = 0;
		gbc_txtNomeCliente.gridy = 1;
		layeredPanePesquisarCliente.add(txtNomeCliente, gbc_txtNomeCliente);
		txtNomeCliente.setColumns(10);
		
		formattedTextFieldCpfCliente = new JFormattedTextField(mascara("###.###.###-##"));
		GridBagConstraints gbc_formattedTextFieldCpfCliente = new GridBagConstraints();
		gbc_formattedTextFieldCpfCliente.gridwidth = 2;
		gbc_formattedTextFieldCpfCliente.insets = new Insets(0, 0, 5, 5);
		gbc_formattedTextFieldCpfCliente.fill = GridBagConstraints.HORIZONTAL;
		gbc_formattedTextFieldCpfCliente.gridx = 1;
		gbc_formattedTextFieldCpfCliente.gridy = 1;
		layeredPanePesquisarCliente.add(formattedTextFieldCpfCliente, gbc_formattedTextFieldCpfCliente);

		JButton btnPesquisarCliente = new JButton("Localizar (ENTER)");
		btnPesquisarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				List<Cliente> cliente;
				if(!(txtNomeCliente.getText().equals(""))){
					
					cliente = ClienteDAO.buscarPorNome(txtNomeCliente.getText());
					
					clientesListados = cliente.size();
					lblQuantidadeClienteListados.setText(Integer.toString(clientesListados));
					
					TabelaClienteBuscaRapida tabelaClienteBuscaRapida;
					tabelaClienteBuscaRapida = new TabelaClienteBuscaRapida(cliente);
					tabelaCliente.setModel(tabelaClienteBuscaRapida);
					
				}else if(!(formattedTextFieldCpfCliente.getText().equals("___.___.___-__"))){
					cliente = ClienteDAO.buscarPorCpf(formattedTextFieldCpfCliente.getText());
					
					clientesListados = cliente.size();
					lblQuantidadeClienteListados.setText(Integer.toString(clientesListados));
					
					TabelaClienteBuscaRapida tabelaClienteBuscaRapida;
					tabelaClienteBuscaRapida = new TabelaClienteBuscaRapida(cliente);
					tabelaCliente.setModel(tabelaClienteBuscaRapida);
					
				}else{
					JOptionPane.showMessageDialog(null, "Selecione um m�todo de pesquisa.");
				}
				
				txtNomeCliente.setText("");
				formattedTextFieldCpfCliente.setText("");
				
			}
		});
		btnPesquisarCliente.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnPesquisarCliente = new GridBagConstraints();
		gbc_btnPesquisarCliente.gridwidth = 2;
		gbc_btnPesquisarCliente.fill = GridBagConstraints.BOTH;
		gbc_btnPesquisarCliente.insets = new Insets(0, 0, 5, 0);
		gbc_btnPesquisarCliente.gridx = 1;
		gbc_btnPesquisarCliente.gridy = 2;
		layeredPanePesquisarCliente.add(btnPesquisarCliente, gbc_btnPesquisarCliente);


		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.anchor = GridBagConstraints.SOUTH;
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 16;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 0, 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);
		
		JButton btnEditarCliente = new JButton("Editar");
		btnEditarCliente.setEnabled(false);
		btnEditarCliente.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Cliente c = ClienteDAO.buscarPorCodigo(codCliente);
				Endereco end = EnderecoDAO.buscarPorCodigo(c.getEndereco().getCodEndereco());
				c.setEndereco(end);
				
				EditarCliente editarCliente = new EditarCliente(c);
				editarCliente.setVisible(true);
				editarCliente.setResizable(false);
				editarCliente.setLocationRelativeTo(null);

			}
		});
		
		btnEditarCliente.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditarCliente = new GridBagConstraints();
		gbc_btnEditarCliente.gridheight = 2;
		gbc_btnEditarCliente.anchor = GridBagConstraints.EAST;
		gbc_btnEditarCliente.insets = new Insets(0, 0, 5, 5);
		gbc_btnEditarCliente.gridx = 2;
		gbc_btnEditarCliente.gridy = 0;
		btnEditarCliente.setVisible(false);
		panel.add(btnEditarCliente, gbc_btnEditarCliente);
		
		
		JScrollPane scrollPaneCliente = new JScrollPane();
		GridBagConstraints gbc_scrollPaneCliente = new GridBagConstraints();
		gbc_scrollPaneCliente.gridheight = 2;
		gbc_scrollPaneCliente.gridwidth = 3;
		gbc_scrollPaneCliente.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneCliente.gridx = 0;
		gbc_scrollPaneCliente.gridy = 3;
		layeredPanePesquisarCliente.add(scrollPaneCliente, gbc_scrollPaneCliente);
		
		tabelaCliente = new JTable();
		tabelaCliente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// pega o c�digo do cliente na linha que o usu�rio selecionar
				// e armazena na vari�vel global codCliente
				codCliente = (int)tabelaCliente.getValueAt(tabelaCliente.getSelectedRow(), 0);
				
				// abilita o bot�o quando o usu�rio selecionar algum produto
				// na tabela
				btnEditarCliente.setEnabled(true);
			}
		});
		List<Cliente> clientes = ClienteDAO.buscarTodosCliente();
		//retorna a quantidade de clientess listados
		clientesListados = clientes.size();
		
		
		TabelaClienteBuscaRapida tabelaClienteBuscaRapida;
		tabelaClienteBuscaRapida = new TabelaClienteBuscaRapida(clientes);
		tabelaCliente.setModel(tabelaClienteBuscaRapida);
		
		scrollPaneCliente.setViewportView(tabelaCliente);
		

		JLabel lblProdutosListados = new JLabel("Produtos Listados:");

		GridBagConstraints gbc_lblProdutosListados = new GridBagConstraints();
		gbc_lblProdutosListados.insets = new Insets(0, 0, 5, 5);
		gbc_lblProdutosListados.gridx = 0;
		gbc_lblProdutosListados.gridy = 0;
		panel.add(lblProdutosListados, gbc_lblProdutosListados);

		lblProdutosListados.setText("Produtos Listados:");
		
		JLabel lblClientesListados = new JLabel("Clientes Listados:");
		lblClientesListados.setVisible(false);
		GridBagConstraints gbc_lblClientesListados = new GridBagConstraints();
		gbc_lblClientesListados.insets = new Insets(0, 0, 5, 5);
		gbc_lblClientesListados.gridx = 0;
		gbc_lblClientesListados.gridy = 0;
		panel.add(lblClientesListados, gbc_lblClientesListados);
		

		lblProdutosListados.setText("Produtos Listados:");

		JButton btnCadastrarProduto = new JButton("Cadastrar Produto");
		btnCadastrarProduto.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/produto24.png")));

		btnCadastrarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroProduto cadProduto = new CadastroProduto();
				cadProduto.setVisible(true);
				cadProduto.setResizable(false);
				cadProduto.setLocationRelativeTo(null);
			}
		});

		GridBagConstraints gbc_btnCadastrarProduto = new GridBagConstraints();
		gbc_btnCadastrarProduto.gridheight = 2;
		gbc_btnCadastrarProduto.anchor = GridBagConstraints.EAST;
		gbc_btnCadastrarProduto.insets = new Insets(0, 0, 5, 5);
		gbc_btnCadastrarProduto.gridx = 1;
		gbc_btnCadastrarProduto.gridy = 0;

		JButton btnCadastrarCliente = new JButton("Cadastrar Cliente");
		btnCadastrarCliente.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/iconCliente24.png")));

		btnCadastrarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroCliente cadCliente = new CadastroCliente();
				cadCliente.setVisible(true);
				cadCliente.setResizable(false);
				cadCliente.setLocationRelativeTo(null);
			}
		});

		JButton btnEditarProduto = new JButton("Editar");
		btnEditarProduto.setEnabled(false);
		btnEditarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Produto p = ProdutoDAO.buscarPorCodigo2(codProduto);
				
				EditarProduto produto = new EditarProduto(p);
				produto.setResizable(false);
				produto.setLocationRelativeTo(null);
				produto.setVisible(true);
				
				
			}
		});
		btnEditarProduto.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditarProduto = new GridBagConstraints();
		gbc_btnEditarProduto.gridheight = 2;
		gbc_btnEditarProduto.anchor = GridBagConstraints.EAST;
		gbc_btnEditarProduto.insets = new Insets(0, 0, 5, 5);
		gbc_btnEditarProduto.gridx = 2;
		gbc_btnEditarProduto.gridy = 0;
		panel.add(btnEditarProduto, gbc_btnEditarProduto);

	

		tabelaProduto = new JTable();
		tabelaProduto.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// pega o c�digo do produto na linha que o usu�rio selecionar
				// e armazena na vari�vel global codProduto
				codProduto = (int) tabelaProduto.getValueAt(tabelaProduto.getSelectedRow(), 0);
				
				// abilita o bot�o quando o usu�rio selecionar algum produto
				// na tabela
				btnEditarProduto.setEnabled(true);

			}
		});

		List<Produto> produtos = ProdutoDAO.consultarTodosProdutos();
		//retorna a quantidade de produtos listados
		produtosListados = produtos.size();
		
		
		TabelaProdutoBuscaRapida tabelaProdutoBuscaRapida;
		tabelaProdutoBuscaRapida = new TabelaProdutoBuscaRapida(produtos);
		tabelaProduto.setModel(tabelaProdutoBuscaRapida);
		scrollPaneProduto.setViewportView(tabelaProduto);
		

	

		GridBagConstraints gbc_btnCadastrarCliente = new GridBagConstraints();
		gbc_btnCadastrarCliente.gridheight = 2;
		gbc_btnCadastrarCliente.anchor = GridBagConstraints.EAST;
		gbc_btnCadastrarCliente.insets = new Insets(0, 0, 5, 5);
		gbc_btnCadastrarCliente.gridx = 1;
		gbc_btnCadastrarCliente.gridy = 0;

		panel.add(btnCadastrarProduto, gbc_btnCadastrarProduto);
		panel.add(btnCadastrarCliente, gbc_btnCadastrarCliente);
		btnCadastrarCliente.setVisible(false);
		
		
		JButton btnPesquisarProduto = new JButton("Localizar (ENTER)");
		btnPesquisarProduto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				List<Produto> produto;

				if (!(txtNome.getText().equals(""))) {
					produto = ProdutoDAO.buscarPorNome(txtNome.getText());
					//retorna o quantidade de produtos listados
					produtosListados = produto.size();
					//joga aquantidade de produtos listados na label
					lblQuantidadeProdutosListados.setText(Integer.toString(produtosListados));
					TabelaProdutoBuscaRapida tabelaProdutoBuscaRapida;
					tabelaProdutoBuscaRapida = new TabelaProdutoBuscaRapida(produto);
					tabelaProduto.setModel(tabelaProdutoBuscaRapida);
					
				} else if (!(txtCodigoBarra.getText().equals(""))) {
					produto = ProdutoDAO.buscarPorCodigo(Integer.parseInt(txtCodigoBarra.getText()));
					//retorna o quantidade de produtos listados
					produtosListados = produto.size();
					//joga aquantidade de produtos listados na label
					lblQuantidadeProdutosListados.setText(Integer.toString(produtosListados));
					
					
					TabelaProdutoBuscaRapida tabelaProdutoBuscaRapida;
					tabelaProdutoBuscaRapida = new TabelaProdutoBuscaRapida(produto);
					tabelaProduto.setModel(tabelaProdutoBuscaRapida);

				}else if(!(txtFornecedor.getText().equals(""))){
					produto = ProdutoDAO.buscarPorNomeFornecedor(txtFornecedor.getText());
					//retorna o quantidade de produtos listados
					produtosListados = produto.size();
					//joga aquantidade de produtos listados na label
					lblQuantidadeProdutosListados.setText(Integer.toString(produtosListados));
					
					TabelaProdutoBuscaRapida tabelaProdutoBuscaRapida;
					tabelaProdutoBuscaRapida = new TabelaProdutoBuscaRapida(produto);
					tabelaProduto.setModel(tabelaProdutoBuscaRapida);
				}else{
					JOptionPane.showMessageDialog(null, "Selecione um m�todo de pesquisa.");
				}
				
				limparCampos();
				
			}

		});
		btnPesquisarProduto.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnPesquisarProduto = new GridBagConstraints();
		gbc_btnPesquisarProduto.insets = new Insets(0, 0, 5, 0);
		gbc_btnPesquisarProduto.gridx = 2;
		gbc_btnPesquisarProduto.gridy = 3;
		layeredPanePesquisarProduto.add(btnPesquisarProduto, gbc_btnPesquisarProduto);
		
		
		lblQuantidadeProdutosListados = new JLabel(Integer.toString(produtosListados));
		GridBagConstraints gbc_lblQuantidadeProdutosListados = new GridBagConstraints();
		gbc_lblQuantidadeProdutosListados.anchor = GridBagConstraints.WEST;
		gbc_lblQuantidadeProdutosListados.insets = new Insets(0, 0, 0, 5);
		gbc_lblQuantidadeProdutosListados.gridx = 0;
		gbc_lblQuantidadeProdutosListados.gridy = 1;
		panel.add(lblQuantidadeProdutosListados, gbc_lblQuantidadeProdutosListados);
		
		lblQuantidadeClienteListados = new JLabel(Integer.toString(clientesListados));
		lblQuantidadeClienteListados.setVisible(false);
		GridBagConstraints gbc_lblQuantidadeClienteListados = new GridBagConstraints();
		gbc_lblQuantidadeClienteListados.anchor = GridBagConstraints.WEST;
		gbc_lblQuantidadeClienteListados.insets = new Insets(0, 0, 0, 5);
		gbc_lblQuantidadeClienteListados.gridx = 0;
		gbc_lblQuantidadeClienteListados.gridy = 1;
		panel.add(lblQuantidadeClienteListados, gbc_lblQuantidadeClienteListados);

		tabbedPane.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				if (tabbedPane.getSelectedIndex() == 0) {
					
					lblQuantidadeProdutosListados.setVisible(true);
					lblQuantidadeClienteListados.setVisible(false);

					btnCadastrarProduto.setVisible(true);
					btnCadastrarCliente.setVisible(false);
					
					lblProdutosListados.setVisible(true);
					lblClientesListados.setVisible(false);

					btnEditarProduto.setVisible(true);
					btnEditarCliente.setVisible(false);

				} else if (tabbedPane.getSelectedIndex() == 1) {
					
					lblQuantidadeProdutosListados.setVisible(false);
					lblQuantidadeClienteListados.setVisible(true);

					btnCadastrarProduto.setVisible(false);
					btnCadastrarCliente.setVisible(true);
					
					lblProdutosListados.setVisible(false);
					lblClientesListados.setVisible(true);

					btnEditarProduto.setVisible(false);
					btnEditarCliente.setVisible(true);
					
					
				}
			}
		});

		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				dispose();

			}
		});
		btnFechar.setIcon(new ImageIcon(BuscaRapida.class.getResource("/imagens/fechar.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.gridheight = 2;
		gbc_btnFechar.insets = new Insets(0, 0, 5, 0);
		gbc_btnFechar.anchor = GridBagConstraints.EAST;
		gbc_btnFechar.gridx = 3;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);

		

	}
	
	public void limparCampos(){
		
		txtNome.setText("");
		txtCodigoBarra.setText("");
		txtFornecedor.setText("");
		
	}
	
	public MaskFormatter mascara(String Mascara) {
		MaskFormatter F_Mascara = new MaskFormatter();
		try {
			F_Mascara.setMask(Mascara); // Atribui a mascara
			F_Mascara.setPlaceholderCharacter('_'); // Caracter para
													// preenchimento
		} catch (Exception excecao) {
			excecao.printStackTrace();
		}
		return F_Mascara;
	}

}
