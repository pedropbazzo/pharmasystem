package view.TM;

import java.text.DateFormat;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Produto;

public class TabelaProdutoBuscaRapida extends AbstractTableModel {
	
	private final List<Produto> produtos;
	
	public TabelaProdutoBuscaRapida(List<Produto> produtos) {
		this.produtos = produtos;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 6;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		
		return this.produtos.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Produto p = produtos.get(linha);
		
		switch (coluna) {
		case 0:
			return p.getCodigo();
		case 1:
			return p.getNome();
		case 2:
			return p.getValorVenda();
		case 3:
			return p.getQuantidade();
		case 4:
			return DateFormat.getDateInstance(DateFormat.MEDIUM).format(p.getVencimento().getTime());
		case 5:
			return p.getCategoria();
		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "C�digo";
		case 1:
			return "Nome";
		case 2:
			return "Valor Venda";
		case 3:
			return "Quantidade";
		case 4:
			return "Vencimento";
		case 5:
			return "Categoria";
		default :
			return null;
			
		}
		
	}

}