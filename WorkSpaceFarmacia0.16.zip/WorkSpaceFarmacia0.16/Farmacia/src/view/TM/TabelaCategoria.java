package view.TM;

import java.text.DateFormat;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Categoria;
import model.Produto;

public class TabelaCategoria extends AbstractTableModel {
	
	private final List<Categoria> categorias;
	
	public TabelaCategoria(List<Categoria> categorias) {
		this.categorias = categorias;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 1;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		
		return this.categorias.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Categoria c = categorias.get(linha);
		
		switch (coluna) {
		case 0:
			return c.getNomeCategoria();
		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "Nome";

		default :
			return null;
			
		}
		
	}

}