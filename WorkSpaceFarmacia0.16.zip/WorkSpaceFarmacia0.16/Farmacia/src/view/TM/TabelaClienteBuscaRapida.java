package view.TM;

import java.text.DateFormat;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Cliente;

public class TabelaClienteBuscaRapida extends AbstractTableModel {
	
	private final List<Cliente> clientes;
	
	public TabelaClienteBuscaRapida(List<Cliente> clientes) {
		this.clientes = clientes;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 6;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		return this.clientes.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Cliente c = clientes.get(linha);
		
		switch (coluna) {
		case 0:
			return c.getCodigoCliente();
		case 1:
			return c.getNome();
		case 2:
			return c.getTelefone();
		case 3:
			return c.getEmail();
		case 4:
			return c.getSexo();
		case 5:
			return c.getCpf();

		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "C�digo";
		case 1:
			return "Nome";
		case 2:
			return "Telefone";
		case 3:
			return "E-mail";
		case 4:
			return "Sexo";
		case 5:
			return "CPF";
		
		default :
			return null;
			
		}
		
	}

}