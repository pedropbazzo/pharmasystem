package view.TM;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Cliente;
import model.Fornecedor;

public class TabelaFornecedor extends AbstractTableModel {
	
	private final List<Fornecedor> fornecedores;
	
	public TabelaFornecedor(List<Fornecedor> fornecedores) {
		this.fornecedores = fornecedores;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 5;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		return this.fornecedores.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Fornecedor f = fornecedores.get(linha);
		
		switch (coluna) {
		case 0:
			return f.getCodigoFornecedor();
		case 1:
			return f.getNome();
		case 2:
			return f.getCnpj();
		case 3:
			return f.getTelefone();
		case 4:
			return f.getEmail();
		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "C�digo";
		case 1:
			return "Nome";
		case 2:
			return "Cnpj";
		case 3:
			return "Telefone";
		case 4:
			return "E-mail";
		
		default :
			return null;
			
		}
		
	}

}