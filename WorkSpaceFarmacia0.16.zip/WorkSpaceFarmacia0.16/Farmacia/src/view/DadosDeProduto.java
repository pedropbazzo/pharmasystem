package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

import javax.swing.ButtonGroup;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JRadioButton;
import javax.swing.border.TitledBorder;

import model.Cliente;
import model.Produto;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.ProdutoDAO;
import view.TM.TabelaCliente;
import view.TM.TabelaProduto;

import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class DadosDeProduto extends JFrame {

	private JPanel contentPane;
	private JTextField txtPesquisarPor;
	private JTextField txtPesquisarPorCodigo;
	
	//String para aparecer quando o usu�rio selecionar o RadioButton
	String opcaoNome = "Pesquisar produto j� cadastrado por [Nome]:";
	String opcaoFornecedor = "Pesquisar produto j� cadastrado por [Fornecedor]:";
	String opcaoCodigo = "Pesquisar produto j� cadastrado por [C�digo]:";

	JLabel lblPesquisarPor = new JLabel(opcaoNome);
	GridBagConstraints gbc_lblPesquisarPor = new GridBagConstraints();
	private JTable table;
	
	int codProduto;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DadosDeProduto produto = new DadosDeProduto();
					produto.setVisible(true);
					produto.setResizable(false);
					produto.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DadosDeProduto() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 777, 532);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{815, 0};
		gbl_contentPane.rowHeights = new int[]{14, 289, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblCliente = new JLabel("Produto");
		GridBagConstraints gbc_lblCliente = new GridBagConstraints();
		gbc_lblCliente.anchor = GridBagConstraints.NORTH;
		gbc_lblCliente.insets = new Insets(0, 0, 5, 0);
		gbc_lblCliente.gridx = 0;
		gbc_lblCliente.gridy = 0;
		contentPane.add(lblCliente, gbc_lblCliente);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		
		JLayeredPane layeredPaneListaDeCliente = new JLayeredPane();
		layeredPaneListaDeCliente.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tabbedPane.addTab("Lista dos Produtos", null, layeredPaneListaDeCliente, null);
		GridBagLayout gbl_layeredPaneListaDeCliente = new GridBagLayout();
		gbl_layeredPaneListaDeCliente.columnWidths = new int[]{0, 0};
		gbl_layeredPaneListaDeCliente.rowHeights = new int[]{0, 0, 0};
		gbl_layeredPaneListaDeCliente.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_layeredPaneListaDeCliente.rowWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		layeredPaneListaDeCliente.setLayout(gbl_layeredPaneListaDeCliente);
		
		
		
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 6;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridheight = 3;
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 7;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		
		//local da label Pesquisar produto por
		gbc_lblPesquisarPor.gridwidth = 3;
		gbc_lblPesquisarPor.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPor.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPor.gridx = 0;
		gbc_lblPesquisarPor.gridy = 0;
		panel.add(lblPesquisarPor, gbc_lblPesquisarPor);
		
		txtPesquisarPor = new JTextField();
		txtPesquisarPor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				txtPesquisarPor.setText(txtPesquisarPor.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtPesquisarPor = new GridBagConstraints();
		gbc_txtPesquisarPor.gridwidth = 5;
		gbc_txtPesquisarPor.insets = new Insets(0, 0, 5, 5);
		gbc_txtPesquisarPor.fill = GridBagConstraints.BOTH;
		gbc_txtPesquisarPor.gridx = 0;
		gbc_txtPesquisarPor.gridy = 1;
		panel.add(txtPesquisarPor, gbc_txtPesquisarPor);
		txtPesquisarPor.setColumns(10);
		
		//essa textField est� dezabilitada, ela s� ser� abilitada quando o usu�rio selecionar o radioButton C�digo.
		txtPesquisarPorCodigo = new JTextField();
		txtPesquisarPorCodigo.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e){
				txtPesquisarPorCodigo.setText(txtPesquisarPorCodigo.getText().replaceAll("[^0-9]", ""));
			}
		});
		GridBagConstraints gbc_txtPesquisarPorCodigo = new GridBagConstraints();
		gbc_txtPesquisarPorCodigo.gridwidth = 5;
		gbc_txtPesquisarPorCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_txtPesquisarPorCodigo.fill = GridBagConstraints.BOTH;
		gbc_txtPesquisarPorCodigo.gridx = 0;
		gbc_txtPesquisarPorCodigo.gridy = 1;
		panel.add(txtPesquisarPorCodigo, gbc_txtPesquisarPorCodigo);
		txtPesquisarPorCodigo.setVisible(false);
		txtPesquisarPorCodigo.setColumns(10);
		
		//=======================================================================
		
		JButton btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				CadastroProduto cadProduto = new CadastroProduto();
				cadProduto.setVisible(true);
				cadProduto.setResizable(false);
				cadProduto.setLocationRelativeTo(null);
				
			}
		});
		
		JPanel painelMudosDePesquisas = new JPanel(new GridLayout(2, 1));
		painelMudosDePesquisas.setBorder(new TitledBorder(null, "Modos de pesquisas dispon\u00EDveis:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GridBagConstraints gbc_painelMudosDePesquisas = new GridBagConstraints();
		gbc_painelMudosDePesquisas.gridwidth = 2;
		gbc_painelMudosDePesquisas.gridheight = 3;
		gbc_painelMudosDePesquisas.insets = new Insets(0, 0, 5, 5);
		gbc_painelMudosDePesquisas.fill = GridBagConstraints.BOTH;
		gbc_painelMudosDePesquisas.gridx = 5;
		gbc_painelMudosDePesquisas.gridy = 0;
		panel.add(painelMudosDePesquisas, gbc_painelMudosDePesquisas);
		
		JRadioButton radioButtonNome = new JRadioButton("Nome");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�Nome�
		radioButtonNome.setActionCommand("Nome");
		radioButtonNome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoNome);
				txtPesquisarPor.setText("");
				txtPesquisarPor.setVisible(true);
				txtPesquisarPorCodigo.setVisible(false);
				
			}
		});
		radioButtonNome.setSelected(true);
		painelMudosDePesquisas.add(radioButtonNome);
		
		JRadioButton radioButtonFornecedor = new JRadioButton("Fornecedor");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�Fornecedor�
		radioButtonFornecedor.setActionCommand("Fornecedor");
		radioButtonFornecedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoFornecedor);
				txtPesquisarPor.setVisible(true);
				txtPesquisarPorCodigo.setVisible(false);
				
			}
		});
		painelMudosDePesquisas.add(radioButtonFornecedor);
		
		JRadioButton radioButtonCodigo = new JRadioButton("C�digo");
		//Isto vai fazer com que ao clicar no bot�o, o Listener receba a palavra
		//�C�digo�
		radioButtonCodigo.setActionCommand("C�digo");

		radioButtonCodigo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblPesquisarPor.setText(opcaoCodigo);
				txtPesquisarPorCodigo.setText("");
				txtPesquisarPor.setVisible(false);
				txtPesquisarPorCodigo.setVisible(true);
				
			}
		});
		painelMudosDePesquisas.add(radioButtonCodigo);
		
		ButtonGroup grupo = new ButtonGroup();
		grupo.add(radioButtonNome);
		grupo.add(radioButtonFornecedor);
		grupo.add(radioButtonCodigo);
		
		
		btnNovo.setIcon(new ImageIcon(DadosDeProduto.class.getResource("/imagens/novo2.png")));
		GridBagConstraints gbc_btnNovo = new GridBagConstraints();
		gbc_btnNovo.insets = new Insets(0, 0, 0, 5);
		gbc_btnNovo.fill = GridBagConstraints.VERTICAL;
		gbc_btnNovo.anchor = GridBagConstraints.WEST;
		gbc_btnNovo.gridx = 0;
		gbc_btnNovo.gridy = 2;
		panel.add(btnNovo, gbc_btnNovo);
		
		JButton btnApagar = new JButton("Apagar");
		btnApagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				int resposta = 0;
				
				resposta = JOptionPane.showConfirmDialog(null, "Deseja excluir o Produto?", "Janela de confirma��o", JOptionPane.YES_NO_OPTION);
				
				if(resposta == JOptionPane.YES_OPTION){
					//essa linha apagar o cliente pelo c�digo que veio da sele��o na tabela
					ProdutoDAO.excluirProduto(codProduto);
					JOptionPane.showMessageDialog(null, "Produto excluido com sucesso.");
				}
				
			}
		});
		btnApagar.setEnabled(false);
		btnApagar.setIcon(new ImageIcon(DadosDeProduto.class.getResource("/imagens/Apagar24.png")));
		GridBagConstraints gbc_btnApagar = new GridBagConstraints();
		gbc_btnApagar.insets = new Insets(0, 0, 0, 5);
		gbc_btnApagar.gridx = 1;
		gbc_btnApagar.gridy = 2;
		panel.add(btnApagar, gbc_btnApagar);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Produto p = ProdutoDAO.buscarPorCodigo2(codProduto);
				
				EditarProduto produto = new EditarProduto(p);
				produto.setResizable(false);
				produto.setLocationRelativeTo(null);
				produto.setVisible(true);
				
				
				
			}
		});
		btnEditar.setEnabled(false);
		btnEditar.setIcon(new ImageIcon(DadosDeProduto.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditar = new GridBagConstraints();
		gbc_btnEditar.insets = new Insets(0, 0, 0, 5);
		gbc_btnEditar.gridx = 2;
		gbc_btnEditar.gridy = 2;
		panel.add(btnEditar, gbc_btnEditar);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridheight = 2;
		gbc_scrollPane.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 0;
		layeredPaneListaDeCliente.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//pega o c�digo do cliente na linha que o usu�rio selecionar
				//e armazena na vari�vel global codCliente
				codProduto = (int) table.getValueAt(table.getSelectedRow(), 0);
		 		
				//abilita os bot�es quando o usu�rio selecionar algum cliente na tabela
				btnApagar.setEnabled(true);
				btnEditar.setEnabled(true);
			}
		});
		
		List<Produto> produtos = ProdutoDAO.consultarTodosProdutos();
		TabelaProduto tabelaProduto;
		
		tabelaProduto = new TabelaProduto(produtos);
		table.setModel(tabelaProduto);
		scrollPane.setViewportView(table);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String comando = grupo.getSelection().getActionCommand();
				
				List<Produto> p = null;
				
				// se o texto do radioButton for igual a "Nome"
				if(comando.equals("Nome")) {
					
					
						p = ProdutoDAO.buscarPorNome(txtPesquisarPor.getText());
						
						TabelaProduto tabelaProduto;
						tabelaProduto = new TabelaProduto(p);
						table.setModel(tabelaProduto);
				
				// se o texto do radioButton for igual a "C�digo"	
				}else if(comando.equals("C�digo")){
					
					if(!(txtPesquisarPorCodigo.getText().equals(""))) {
						
						p = ProdutoDAO.buscarPorCodigo(Integer.parseInt(txtPesquisarPorCodigo.getText()));
						
						
						TabelaProduto tabelaProduto;
						tabelaProduto = new TabelaProduto(p);
						table.setModel(tabelaProduto);
					
					}else{
						JOptionPane.showMessageDialog(null, "Digite algum c�digo.");
						
					}
					
				// se o texto do radioButton for igual a "Fornecedor"
				}else{
					
					
						p = ProdutoDAO.buscarPorNomeFornecedor(txtPesquisarPor.getText());
						
						TabelaProduto tabelaProduto;
						tabelaProduto = new TabelaProduto(p);
						table.setModel(tabelaProduto);
					
				}
				
				
				btnApagar.setEnabled(false);
				btnEditar.setEnabled(false);
				
				
			}
		});
		btnPesquisar.setIcon(new ImageIcon(DadosDeProduto.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnPesquisar = new GridBagConstraints();
		gbc_btnPesquisar.insets = new Insets(0, 0, 0, 5);
		gbc_btnPesquisar.gridx = 3;
		gbc_btnPesquisar.gridy = 2;
		panel.add(btnPesquisar, gbc_btnPesquisar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
			}
		});
		btnFechar.setIcon(new ImageIcon(DadosDeProduto.class.getResource("/imagens/fechar.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.insets = new Insets(0, 0, 0, 5);
		gbc_btnFechar.gridx = 4;
		gbc_btnFechar.gridy = 2;
		panel.add(btnFechar, gbc_btnFechar);
		
		
		
		
		
	}
}
