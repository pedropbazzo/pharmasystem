package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

import util.ManipularImagem;

import javax.swing.JTextPane;
import com.toedter.calendar.JDateChooser;

import model.Categoria;
import model.Endereco;
import model.Produto;
import model.DAO.CategoriaDAO;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.ProdutoDAO;
import java.awt.event.KeyAdapter;

public class EditarProduto extends JFrame {

	private JPanel contentPane;
	private JTextField txtDescricao;
	private JTextField txtCodigoBarra;
	private JTextField txtValorCusto;
	private JTextField txtValorVenda;
	private JTextField txtMarca;
	private JTextField txtFornecedor;
	private JTextField txtQuantidade;
	private JTextField txtLote;

	
	private BufferedImage imagem;
	private JTextField txtNome;
	
	
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarProduto cadCliente = new EditarProduto();
					cadCliente.setVisible(true);
					cadCliente.setResizable(false);
					cadCliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public EditarProduto(Produto p) {
		setTitle("Editar dados do Produto");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 715, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JLayeredPane layeredPaneInformacpesBasicasDeProduto = new JLayeredPane();
		tabbedPane.addTab("Informa\u00E7\u00F5es b\u00E1sicas do Produto", new ImageIcon(EditarProduto.class.getResource("/imagens/produto24.png")), layeredPaneInformacpesBasicasDeProduto, null);
		GridBagLayout gbl_layeredPaneInformacpesBasicasDeProduto = new GridBagLayout();
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWeights = new double[]{1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		layeredPaneInformacpesBasicasDeProduto.setLayout(gbl_layeredPaneInformacpesBasicasDeProduto);
		
		JLabel lblNome = new JLabel("Nome:   ");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.WEST;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		layeredPaneInformacpesBasicasDeProduto.add(lblNome, gbc_lblNome);
		
		txtNome = new JTextField(p.getNome());
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtNome.setText(txtNome.getText().toUpperCase());
			}
		});
		
		JLabel lblNewLabel = new JLabel("Descri\u00E7\u00E3o do Produto:");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 4;
		gbc_lblNewLabel.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 5;
		gbc_lblNewLabel.gridy = 0;
		layeredPaneInformacpesBasicasDeProduto.add(lblNewLabel, gbc_lblNewLabel);
		
		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.gridwidth = 5;
		gbc_txtNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 1;
		layeredPaneInformacpesBasicasDeProduto.add(txtNome, gbc_txtNome);
		txtNome.setColumns(10);
		
		
		txtDescricao = new JTextField(p.getDescricao());
		txtDescricao.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtDescricao.setText(txtDescricao.getText().toUpperCase());
				
			}
		});
		GridBagConstraints gbc_txtDescricao = new GridBagConstraints();
		gbc_txtDescricao.gridwidth = 4;
		gbc_txtDescricao.insets = new Insets(0, 0, 5, 0);
		gbc_txtDescricao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDescricao.gridx = 5;
		gbc_txtDescricao.gridy = 1;
		layeredPaneInformacpesBasicasDeProduto.add(txtDescricao, gbc_txtDescricao);
		txtDescricao.setColumns(10);
		
		JLabel lblCodigoBarra = new JLabel("C\u00F3digo De Barra:");
		GridBagConstraints gbc_lblCodigoBarra = new GridBagConstraints();
		gbc_lblCodigoBarra.insets = new Insets(0, 0, 5, 5);
		gbc_lblCodigoBarra.anchor = GridBagConstraints.WEST;
		gbc_lblCodigoBarra.gridx = 0;
		gbc_lblCodigoBarra.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCodigoBarra, gbc_lblCodigoBarra);
		
		JLabel lblValorCusto = new JLabel("Valor custo:");
		GridBagConstraints gbc_lblValorCusto = new GridBagConstraints();
		gbc_lblValorCusto.anchor = GridBagConstraints.WEST;
		gbc_lblValorCusto.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorCusto.gridx = 1;
		gbc_lblValorCusto.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorCusto, gbc_lblValorCusto);
		
		JLabel lblValorVenda = new JLabel("Valor venda:");
		GridBagConstraints gbc_lblValorVenda = new GridBagConstraints();
		gbc_lblValorVenda.anchor = GridBagConstraints.WEST;
		gbc_lblValorVenda.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorVenda.gridx = 3;
		gbc_lblValorVenda.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorVenda, gbc_lblValorVenda);
		
		JLabel lblDataDeFabricao = new JLabel("Data de Fabrica��o Dia/M�s/Ano");
		GridBagConstraints gbc_lblDataDeFabricao = new GridBagConstraints();
		gbc_lblDataDeFabricao.anchor = GridBagConstraints.WEST;
		gbc_lblDataDeFabricao.insets = new Insets(0, 0, 5, 5);
		gbc_lblDataDeFabricao.gridx = 5;
		gbc_lblDataDeFabricao.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblDataDeFabricao, gbc_lblDataDeFabricao);
		
		JLabel lblCategoria = new JLabel("Categoria:");
		GridBagConstraints gbc_lblCategoria = new GridBagConstraints();
		gbc_lblCategoria.gridwidth = 2;
		gbc_lblCategoria.anchor = GridBagConstraints.WEST;
		gbc_lblCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_lblCategoria.gridx = 6;
		gbc_lblCategoria.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCategoria, gbc_lblCategoria);
		
		txtCodigoBarra = new JTextField();
		txtCodigoBarra.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				txtCodigoBarra.setText(txtCodigoBarra.getText().replaceAll("[^0-9]", ""));
				
			}
		});
		
		txtCodigoBarra.setText(Integer.toString(p.getCodigo()));
		
		GridBagConstraints gbc_txtCodigoBarra = new GridBagConstraints();
		gbc_txtCodigoBarra.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigoBarra.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigoBarra.gridx = 0;
		gbc_txtCodigoBarra.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(txtCodigoBarra, gbc_txtCodigoBarra);
		txtCodigoBarra.setColumns(10);
		
		//================================================================================
		DecimalFormat valorCustoFormat = new DecimalFormat("#,###,###.00") ;
	    NumberFormatter formatterValorCusto = new NumberFormatter(valorCustoFormat) ;
	    formatterValorCusto.setFormat(valorCustoFormat) ;
	    formatterValorCusto.setAllowsInvalid(false) ; 

	    JFormattedTextField textFieldValorCusto = new JFormattedTextField ( ) ;
	    textFieldValorCusto.setFormatterFactory ( new DefaultFormatterFactory ( formatterValorCusto ) ) ;
	    
	    //pegar o valor de custo do banco
	    String valorDoBancoCusto = Double.toString(p.getValorCusto());
	    //troca o ponto do banco que est� em double e p�e a virgula por causa da mascara
	    String valorFormatadoCusto = valorDoBancoCusto.replace(".", ",");
	  //joga o valor formatado no campo de valor custo
	    textFieldValorCusto.setText(valorFormatadoCusto);
	    
		GridBagConstraints gbc_textFieldValorCusto = new GridBagConstraints();
		gbc_textFieldValorCusto.gridwidth = 2;
		gbc_textFieldValorCusto.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldValorCusto.fill = GridBagConstraints.HORIZONTAL;
		gbc_textFieldValorCusto.gridx = 1;
		gbc_textFieldValorCusto.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(textFieldValorCusto, gbc_textFieldValorCusto);
		
		
		
		//===================================================================================
		DecimalFormat valorVendaFormat = new DecimalFormat("#,###,###.00") ;
	    NumberFormatter formatterValorVenda = new NumberFormatter(valorVendaFormat) ;
	    formatterValorVenda.setFormat(valorVendaFormat) ;
	    formatterValorVenda.setAllowsInvalid(false) ; 

	    JFormattedTextField textFieldValorVenda = new JFormattedTextField ( ) ;
	    textFieldValorVenda.setFormatterFactory ( new DefaultFormatterFactory ( formatterValorVenda ) ) ;
	    //pegar o valor de venda do banco
	    String valorDoBancoVenda = Double.toString(p.getValorVenda());
	    //troca o ponto do banco que est� em double e p�e a virgula por causa da mascara
	    String valorFormatadoVenda = valorDoBancoVenda.replace(".", ",");
	    //joga o valor formatado no campo de valor venda
	    textFieldValorVenda.setText(valorFormatadoVenda);
		
		GridBagConstraints gbc_textFieldValorVenda = new GridBagConstraints();
		gbc_textFieldValorVenda.gridwidth = 2;
		gbc_textFieldValorVenda.insets = new Insets(0, 0, 5, 5);
		gbc_textFieldValorVenda.fill = GridBagConstraints.HORIZONTAL;
		gbc_textFieldValorVenda.gridx = 3;
		gbc_textFieldValorVenda.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(textFieldValorVenda, gbc_textFieldValorVenda);
		
		
		
		JDateChooser dateChooserFabricacao = new JDateChooser(p.getDataFabricacao());
		GridBagConstraints gbc_dateChooserFabricacao = new GridBagConstraints();
		gbc_dateChooserFabricacao.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooserFabricacao.fill = GridBagConstraints.HORIZONTAL;
		gbc_dateChooserFabricacao.gridx = 5;
		gbc_dateChooserFabricacao.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(dateChooserFabricacao, gbc_dateChooserFabricacao);
		
		
		CategoriaDAO categorias = new CategoriaDAO();
		JComboBox comboBoxCategoria = new JComboBox();
		
		
		for (Categoria c: categorias.consultarTodasCategoria()) {
			comboBoxCategoria.addItem(c);
			
		}
		
		//chamei o buscar todos para poder percorrer a lista e verificar se o item � igual a p.getCategoria()
		//se for categoriaProduto recebe i que � o valor do index referente a categoria salva no banco
		List<Categoria> lCategoria = CategoriaDAO.consultarTodasCategoria();
		int categoriaProduto = 0;
		int n = lCategoria.size();
		String a;
		for (int i = 0; i < n; i++) {
			a = lCategoria.get(i).toString();
			if(a.equals(p.getCategoria())){
				
				categoriaProduto = i;
				
				break;
			}
		}
		
		comboBoxCategoria.setSelectedIndex(categoriaProduto);
		
		
		GridBagConstraints gbc_comboBoxCategoria = new GridBagConstraints();
		gbc_comboBoxCategoria.gridwidth = 2;
		gbc_comboBoxCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_comboBoxCategoria.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBoxCategoria.gridx = 6;
		gbc_comboBoxCategoria.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(comboBoxCategoria, gbc_comboBoxCategoria);
		
		JButton btnNew = new JButton("Nova");
		btnNew.setToolTipText("Nova Categoria");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				CadastroCategoria cadCategoria = new CadastroCategoria();
				cadCategoria.setVisible(true);
				cadCategoria.setResizable(false);
				cadCategoria.setLocationRelativeTo(null);
			}
		});
		GridBagConstraints gbc_btnNew = new GridBagConstraints();
		gbc_btnNew.insets = new Insets(0, 0, 5, 0);
		gbc_btnNew.gridx = 8;
		gbc_btnNew.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(btnNew, gbc_btnNew);
		
		JLabel lblMarca = new JLabel("Marca:");
		GridBagConstraints gbc_lblMarca = new GridBagConstraints();
		gbc_lblMarca.anchor = GridBagConstraints.WEST;
		gbc_lblMarca.insets = new Insets(0, 0, 5, 5);
		gbc_lblMarca.gridx = 0;
		gbc_lblMarca.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblMarca, gbc_lblMarca);
		
		JLabel lblFornecedor = new JLabel("Fornecedor:");
		GridBagConstraints gbc_lblFornecedor = new GridBagConstraints();
		gbc_lblFornecedor.anchor = GridBagConstraints.WEST;
		gbc_lblFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_lblFornecedor.gridx = 1;
		gbc_lblFornecedor.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblFornecedor, gbc_lblFornecedor);
		
		JLabel lblQuantidade = new JLabel("Quantidade:");
		GridBagConstraints gbc_lblQuantidade = new GridBagConstraints();
		gbc_lblQuantidade.anchor = GridBagConstraints.WEST;
		gbc_lblQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_lblQuantidade.gridx = 3;
		gbc_lblQuantidade.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblQuantidade, gbc_lblQuantidade);
		
		JLabel lblLote = new JLabel("Lote:");
		GridBagConstraints gbc_lblLote = new GridBagConstraints();
		gbc_lblLote.anchor = GridBagConstraints.WEST;
		gbc_lblLote.insets = new Insets(0, 0, 5, 5);
		gbc_lblLote.gridx = 5;
		gbc_lblLote.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblLote, gbc_lblLote);
		
		JLabel lblVencimento = new JLabel("Vencimento:");
		GridBagConstraints gbc_lblVencimento = new GridBagConstraints();
		gbc_lblVencimento.gridwidth = 2;
		gbc_lblVencimento.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblVencimento.insets = new Insets(0, 0, 5, 5);
		gbc_lblVencimento.gridx = 6;
		gbc_lblVencimento.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblVencimento, gbc_lblVencimento);
		
		txtMarca = new JTextField(p.getMarca());
		txtMarca.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtMarca.setText(txtMarca.getText().toUpperCase());
				
			}
		});
		GridBagConstraints gbc_txtMarca = new GridBagConstraints();
		gbc_txtMarca.insets = new Insets(0, 0, 5, 5);
		gbc_txtMarca.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtMarca.gridx = 0;
		gbc_txtMarca.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtMarca, gbc_txtMarca);
		txtMarca.setColumns(10);
		
		txtFornecedor = new JTextField(p.getFornecedor());
		txtFornecedor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtFornecedor.setText(txtFornecedor.getText().toUpperCase());
				
				
			}
		});
		GridBagConstraints gbc_txtFornecedor = new GridBagConstraints();
		gbc_txtFornecedor.gridwidth = 2;
		gbc_txtFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_txtFornecedor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFornecedor.gridx = 1;
		gbc_txtFornecedor.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtFornecedor, gbc_txtFornecedor);
		txtFornecedor.setColumns(10);
		
		txtQuantidade = new JTextField();
		txtQuantidade.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				//tudo o que for diferente de 0 at� 9 ser� substituido por espaco vazio, 
				//isto � o txtQuantidade s� aceita n�meros
				txtQuantidade.setText(txtQuantidade.getText().replaceAll("[^0-9]", ""));
			}
		});
		
		txtQuantidade.setText(Integer.toString(p.getQuantidade()));
		
		
		GridBagConstraints gbc_txtQuantidade = new GridBagConstraints();
		gbc_txtQuantidade.gridwidth = 2;
		gbc_txtQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_txtQuantidade.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtQuantidade.gridx = 3;
		gbc_txtQuantidade.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtQuantidade, gbc_txtQuantidade);
		txtQuantidade.setColumns(10);
		
		txtLote = new JTextField(p.getLote());
		txtLote.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtLote.setText(txtLote.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtLote = new GridBagConstraints();
		gbc_txtLote.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLote.insets = new Insets(0, 0, 5, 5);
		gbc_txtLote.gridx = 5;
		gbc_txtLote.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtLote, gbc_txtLote);
		txtLote.setColumns(10);
		
		JDateChooser dateChooserVencimento = new JDateChooser(p.getVencimento());
		GridBagConstraints gbc_dateChooserVencimento = new GridBagConstraints();
		gbc_dateChooserVencimento.gridwidth = 3;
		gbc_dateChooserVencimento.insets = new Insets(0, 0, 5, 0);
		gbc_dateChooserVencimento.fill = GridBagConstraints.BOTH;
		gbc_dateChooserVencimento.gridx = 6;
		gbc_dateChooserVencimento.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(dateChooserVencimento, gbc_dateChooserVencimento);
		
		JLabel lblInformaes = new JLabel("Informa��es adicinionais:");
		GridBagConstraints gbc_lblInformaes = new GridBagConstraints();
		gbc_lblInformaes.anchor = GridBagConstraints.WEST;
		gbc_lblInformaes.gridwidth = 2;
		gbc_lblInformaes.insets = new Insets(0, 0, 5, 5);
		gbc_lblInformaes.gridx = 0;
		gbc_lblInformaes.gridy = 6;
		layeredPaneInformacpesBasicasDeProduto.add(lblInformaes, gbc_lblInformaes);
		
		JTextArea textAreaIformacoesAdicionais = new JTextArea(p.getInformacoesAdicionais());
		textAreaIformacoesAdicionais.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				textAreaIformacoesAdicionais.setText(textAreaIformacoesAdicionais.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.gridwidth = 9;
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 0;
		gbc_textArea.gridy = 7;
		
		//pular de linha quando n�o couber mais na linha
		textAreaIformacoesAdicionais.setLineWrap(true);
						 //descer com a palavra quando ela n�o couber mais na linha
		textAreaIformacoesAdicionais.setWrapStyleWord(true);
						JScrollPane sp = new JScrollPane(textAreaIformacoesAdicionais, 
								 JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
								 JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		layeredPaneInformacpesBasicasDeProduto.add(sp, gbc_textArea);
		
		JLayeredPane layeredPaneObservcoesEFoto = new JLayeredPane();
		tabbedPane.addTab("Observa��es e foto", null, layeredPaneObservcoesEFoto, null);
		GridBagLayout gbl_layeredPaneObservcoesEFoto = new GridBagLayout();
		gbl_layeredPaneObservcoesEFoto.columnWidths = new int[]{0, 0};
		gbl_layeredPaneObservcoesEFoto.rowHeights = new int[]{0, 0};
		gbl_layeredPaneObservcoesEFoto.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_layeredPaneObservcoesEFoto.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		layeredPaneObservcoesEFoto.setLayout(gbl_layeredPaneObservcoesEFoto);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		layeredPaneObservcoesEFoto.add(panel_1, gbc_panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JLabel lblNew = new JLabel("FOTO DO PRODUTO:");
		GridBagConstraints gbc_lblNew = new GridBagConstraints();
		gbc_lblNew.gridwidth = 2;
		gbc_lblNew.insets = new Insets(0, 0, 5, 0);
		gbc_lblNew.gridx = 0;
		gbc_lblNew.gridy = 0;
		panel_1.add(lblNew, gbc_lblNew);
		
		JLabel lblImagem = new JLabel("");
		lblImagem.setToolTipText("Adicione uma imagem");
		lblImagem.setBackground(Color.WHITE);
		GridBagConstraints gbc_lblImagem = new GridBagConstraints();
		gbc_lblImagem.gridwidth = 2;
		gbc_lblImagem.insets = new Insets(0, 0, 5, 5);
		gbc_lblImagem.gridx = 0;
		gbc_lblImagem.gridy = 1;
		panel_1.add(lblImagem, gbc_lblImagem);
		
		JButton btnNewButton = new JButton("Adicinar Imagem");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				  JFileChooser fc = new JFileChooser();
			        int res = fc.showOpenDialog(null);
			        
			        if (res == JFileChooser.APPROVE_OPTION) {
			            File arquivo = fc.getSelectedFile();
			            
			            try {
			                imagem = ManipularImagem.setImagemDimensao(arquivo.getAbsolutePath(), 460, 260);
			                
			                lblImagem.setIcon(new ImageIcon(imagem));

			            } catch (Exception ex) {
			               // System.out.println(ex.printStackTrace().toString());
			            }

			        } else {
			            JOptionPane.showMessageDialog(null, "Voce nao selecionou nenhum arquivo.");
			        }	
			        
			        			
			}
		});
		btnNewButton.setIcon(new ImageIcon(EditarProduto.class.getResource("/imagens/addImagem24.png")));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 2;
		panel_1.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblImagem.setIcon(new ImageIcon());	
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(EditarProduto.class.getResource("/imagens/limpar24.png")));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.anchor = GridBagConstraints.EAST;
		gbc_btnNewButton_1.gridx = 1;
		gbc_btnNewButton_1.gridy = 2;
		panel_1.add(btnNewButton_1, gbc_btnNewButton_1);
		
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.anchor = GridBagConstraints.SOUTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnSalvar = new JButton("Salvar (F2)");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(txtCodigoBarra.getText().equals("")
						|| txtNome.getText().equals("")
						|| txtDescricao.getText().equals("") 
						|| textFieldValorCusto.getText().equals("") 
						|| textFieldValorVenda.getText().equals("")
						|| txtMarca.getText().equals("")
						|| txtFornecedor.getText().equals("")
						|| txtQuantidade.getText().equals("")
						|| txtLote.getText().equals("") 
						|| dateChooserFabricacao.getDate() ==null 
						|| dateChooserVencimento.getDate() ==null){
					JOptionPane.showMessageDialog(null, "Preencha todos os campos");
				} else {
					//pega o conteudo de textFieldValorCusto e joga em valorCusto
					String valorCusto = textFieldValorCusto.getText();
					//pegar o valorCusto e troca o ponto por nada, e pega a v�rgula e troca por ponto
					//para poder converter pra double e jogar no banco
					String valorSemFormatacaoCusto = valorCusto.replace(".", "").replace(",", ".");
					
					//pega o conteudo de textFieldValorVenda e joga em valorVenda
					String valorVenda = textFieldValorVenda.getText();
					//pegar o valorVenda e troca o ponto por nada, e pega a v�rgula e troca por ponto
					//para poder converter pra double e jogar no banco
					String valorSemFormatacaoVenda = valorVenda.replace(".", "").replace(",", ".");
					
					
					
					boolean okproduto = ProdutoDAO.atualizarProduto(txtNome.getText(), Double.parseDouble(valorSemFormatacaoCusto), 
							Double.parseDouble(valorSemFormatacaoVenda), txtDescricao.getText(), dateChooserFabricacao.getDate(), txtMarca.getText(), txtFornecedor.getText(),
							Integer.parseInt(txtQuantidade.getText()), txtLote.getText(), dateChooserVencimento.getDate(), lblImagem.getText(),
							comboBoxCategoria.getSelectedItem().toString(), textAreaIformacoesAdicionais.getText(), Integer.parseInt(txtCodigoBarra.getText()));
					if(okproduto){
						dispose();
						JOptionPane.showMessageDialog(null, "Produto editado com sucesso.");
						
					}else{
						dispose();
						JOptionPane.showMessageDialog(null, "Erro ao editar o produto.");
					}
					
					
				}
				
			}
		});
		btnSalvar.setIcon(new ImageIcon(EditarProduto.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnSalvar.insets = new Insets(0, 0, 0, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 0;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JButton btnFechar = new JButton("Fechar (ESC)");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int resposta = JOptionPane.showConfirmDialog(null,
						"Deseja fechar a janela?", 
						"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
				
				switch(resposta){
				case JOptionPane.YES_OPTION:
					dispose();

					break;
				case JOptionPane.NO_OPTION:
					
				}
				
			}
		});
		btnFechar.setIcon(new ImageIcon(EditarProduto.class.getResource("/imagens/fechar32.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnFechar.gridx = 6;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);
	}
}
