package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Categoria;
import model.DAO.CategoriaDAO;
import view.TM.TabelaCategoria;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class CadastroCategoria extends JFrame {

	private JPanel contentPane;
	private JTextField txtCategoria;
	private JScrollPane scrollPane;
	private JTable table;
	private JButton btnExcluir;

	String nome;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroCategoria cadCategoria = new CadastroCategoria();
					cadCategoria.setVisible(true);
					cadCategoria.setResizable(false);
					cadCategoria.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroCategoria() {
		setTitle("Cadastro de Categoria");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 275, 395);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{31, 232, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 25, 41, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNome = new JLabel("Nome:");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.WEST;
		gbc_lblNome.fill = GridBagConstraints.VERTICAL;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		contentPane.add(lblNome, gbc_lblNome);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!(txtCategoria.getText().isEmpty())) {
					CategoriaDAO.cadastrarCategoria(txtCategoria.getText());
					JOptionPane.showMessageDialog(null, "Categoria cadastrada com sucesso.");
				} else {
					JOptionPane.showMessageDialog(contentPane.getParent(), "Preencha o campo");
				}
				
				txtCategoria.setText("");
				
				List<Categoria> categorias = CategoriaDAO.consultarTodasCategoria();
				TabelaCategoria tabelaCategoria;
				tabelaCategoria = new TabelaCategoria(categorias);
				
				table.setModel(tabelaCategoria);
				
			}
		});
		
		txtCategoria = new JTextField();
		txtCategoria.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtCategoria.setText(txtCategoria.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtCategoria = new GridBagConstraints();
		gbc_txtCategoria.gridwidth = 2;
		gbc_txtCategoria.fill = GridBagConstraints.BOTH;
		gbc_txtCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_txtCategoria.gridx = 1;
		gbc_txtCategoria.gridy = 0;
		contentPane.add(txtCategoria, gbc_txtCategoria);
		txtCategoria.setColumns(10);
		
		scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridheight = 2;
		gbc_scrollPane.gridwidth = 3;
		gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 1;
		contentPane.add(scrollPane, gbc_scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				// pega o c�digo do cliente na linha que o usu�rio selecionar
				// e armazena na vari�vel global codCliente
				nome =(String) table.getValueAt(table.getSelectedRow(), 0);
				
				// abilita o bot�o quando o usu�rio selecionar algum produto
				// na tabela
				btnExcluir.setEnabled(true);
				
			}
		});
		List<Categoria> categorias = CategoriaDAO.consultarTodasCategoria();
		TabelaCategoria tabelaCategoria;
		tabelaCategoria = new TabelaCategoria(categorias);
		
		table.setModel(tabelaCategoria);
		scrollPane.setViewportView(table);
		
		btnSalvar.setIcon(new ImageIcon(CadastroCategoria.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.fill = GridBagConstraints.VERTICAL;
		gbc_btnSalvar.insets = new Insets(0, 0, 0, 5);
		gbc_btnSalvar.anchor = GridBagConstraints.WEST;
		gbc_btnSalvar.gridwidth = 2;
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 3;
		contentPane.add(btnSalvar, gbc_btnSalvar);
		
		btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CategoriaDAO.excluirCategoria(nome);
				JOptionPane.showMessageDialog(null, "Categoria excluida com sucesso.");
				
				List<Categoria> categorias = CategoriaDAO.consultarTodasCategoria();
				TabelaCategoria tabelaCategoria;
				tabelaCategoria = new TabelaCategoria(categorias);
				
				table.setModel(tabelaCategoria);
				
			}
		});
		btnExcluir.setEnabled(false);
		btnExcluir.setIcon(new ImageIcon(CadastroCategoria.class.getResource("/imagens/apagar32.png")));
		GridBagConstraints gbc_btnExcluir = new GridBagConstraints();
		gbc_btnExcluir.fill = GridBagConstraints.BOTH;
		gbc_btnExcluir.gridx = 2;
		gbc_btnExcluir.gridy = 3;
		contentPane.add(btnExcluir, gbc_btnExcluir);
	}

}
