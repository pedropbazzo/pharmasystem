package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;

import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.text.MaskFormatter;

import model.Endereco;
import model.Fornecedor;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.FornecedorDAO;

import com.toedter.calendar.JDateChooser;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class EditarFornecedor extends JFrame {
	
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtTelefone;
	private JTextField txtCidade;
	private JTextField txtUF;
	private JTextField txtEmail;
	private JTextField txtLogradouro;
	private JTextField txtNumero;
	private JTextField txtComplemento;
	private JTextField txtBairro;
	private JTextField txtCep;
	private JTextField txtCnpj;
	private JTextField txtCodifoFornecedor;
	private JFormattedTextField formattedTextFieldCnpj;
	private JFormattedTextField formattedTextFieldTelefone;
	private JComboBox comboBoxUf;
	private JFormattedTextField formattedTextFieldCep;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarFornecedor cadCliente = new EditarFornecedor();
					cadCliente.setVisible(true);
					cadCliente.setResizable(false);
					cadCliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	
	/**
	 * Create the frame.
	 */
	public EditarFornecedor(Fornecedor f) {
		setTitle("Cadastro de Fornecedor");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 638, 438);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tabbedPane.addTab("Informa\u00E7\u00F5es B\u00E1sicas de Fornecedor", new ImageIcon(EditarFornecedor.class.getResource("/imagens/fornecedor24.png")), layeredPane, null);
		GridBagLayout gbl_layeredPane = new GridBagLayout();
		gbl_layeredPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPane.columnWeights = new double[]{1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_layeredPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		layeredPane.setLayout(gbl_layeredPane);
		
		txtNome = new JTextField(f.getNome());
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				
				txtNome.setText(txtNome.getText().toUpperCase());
			}
		});
		
		JLabel lblCdigoautomtico = new JLabel("C\u00F3digo (Autom\u00E1tico)");
		GridBagConstraints gbc_lblCdigoautomtico = new GridBagConstraints();
		gbc_lblCdigoautomtico.anchor = GridBagConstraints.WEST;
		gbc_lblCdigoautomtico.insets = new Insets(0, 0, 5, 5);
		gbc_lblCdigoautomtico.gridx = 0;
		gbc_lblCdigoautomtico.gridy = 0;
		layeredPane.add(lblCdigoautomtico, gbc_lblCdigoautomtico);
		
		JLabel lblNome = new JLabel("Nome do Fornecedor");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.WEST;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 1;
		gbc_lblNome.gridy = 0;
		layeredPane.add(lblNome, gbc_lblNome);
		
		JLabel lblCnpj = new JLabel("CNPJ:");
		lblCnpj.setFont(new Font("Tahoma", Font.PLAIN, 11));
		GridBagConstraints gbc_lblCnpj = new GridBagConstraints();
		gbc_lblCnpj.gridwidth = 3;
		gbc_lblCnpj.anchor = GridBagConstraints.WEST;
		gbc_lblCnpj.insets = new Insets(0, 0, 5, 0);
		gbc_lblCnpj.gridx = 5;
		gbc_lblCnpj.gridy = 0;
		layeredPane.add(lblCnpj, gbc_lblCnpj);
		
		txtCodifoFornecedor = new JTextField();
		txtCodifoFornecedor.setEditable(false);
		GridBagConstraints gbc_txtCodifoFornecedor = new GridBagConstraints();
		gbc_txtCodifoFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodifoFornecedor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodifoFornecedor.gridx = 0;
		gbc_txtCodifoFornecedor.gridy = 1;
		layeredPane.add(txtCodifoFornecedor, gbc_txtCodifoFornecedor);
		txtCodifoFornecedor.setColumns(10);
		
		txtCodifoFornecedor.setText(Integer.toString(f.getCodigoFornecedor()));
		
		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.gridwidth = 4;
		gbc_txtNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.gridx = 1;
		gbc_txtNome.gridy = 1;
		layeredPane.add(txtNome, gbc_txtNome);
		txtNome.setColumns(10);
		
		 formattedTextFieldCnpj = new JFormattedTextField(mascara("##.###.###/####-##"));
		
		GridBagConstraints gbc_formattedTextFieldCnpj = new GridBagConstraints();
		gbc_formattedTextFieldCnpj.gridwidth = 3;
		gbc_formattedTextFieldCnpj.insets = new Insets(0, 0, 5, 0);
		gbc_formattedTextFieldCnpj.fill = GridBagConstraints.HORIZONTAL;
		gbc_formattedTextFieldCnpj.gridx = 5;
		gbc_formattedTextFieldCnpj.gridy = 1;
		layeredPane.add(formattedTextFieldCnpj, gbc_formattedTextFieldCnpj);
		
		formattedTextFieldCnpj.setText(f.getCnpj());
		
		JLabel lblTelefone = new JLabel("Telefone");
		GridBagConstraints gbc_lblTelefone = new GridBagConstraints();
		gbc_lblTelefone.anchor = GridBagConstraints.WEST;
		gbc_lblTelefone.insets = new Insets(0, 0, 5, 5);
		gbc_lblTelefone.gridx = 0;
		gbc_lblTelefone.gridy = 2;
		layeredPane.add(lblTelefone, gbc_lblTelefone);
		
		
		JLabel lblEmail = new JLabel("E-mail");
		GridBagConstraints gbc_lblEmail = new GridBagConstraints();
		gbc_lblEmail.anchor = GridBagConstraints.WEST;
		gbc_lblEmail.insets = new Insets(0, 0, 5, 5);
		gbc_lblEmail.gridx = 1;
		gbc_lblEmail.gridy = 2;
		layeredPane.add(lblEmail, gbc_lblEmail);
		
		formattedTextFieldTelefone = new JFormattedTextField(mascara("(##)####-####"));
		GridBagConstraints gbc_formattedTextFieldTelefone = new GridBagConstraints();
		gbc_formattedTextFieldTelefone.insets = new Insets(0, 0, 5, 5);
		gbc_formattedTextFieldTelefone.fill = GridBagConstraints.HORIZONTAL;
		gbc_formattedTextFieldTelefone.gridx = 0;
		gbc_formattedTextFieldTelefone.gridy = 3;
		layeredPane.add(formattedTextFieldTelefone, gbc_formattedTextFieldTelefone);
		
		formattedTextFieldTelefone.setText(f.getTelefone());
		
		txtEmail = new JTextField(f.getEmail());
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				txtEmail.setText(txtEmail.getText().toLowerCase());
			}
		});
		GridBagConstraints gbc_txtEmail = new GridBagConstraints();
		gbc_txtEmail.gridwidth = 7;
		gbc_txtEmail.insets = new Insets(0, 0, 5, 0);
		gbc_txtEmail.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtEmail.gridx = 1;
		gbc_txtEmail.gridy = 3;
		layeredPane.add(txtEmail, gbc_txtEmail);
		txtEmail.setColumns(10);
		
		
		String[] vetorUf = {"AC", "AL", "AP","AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT",
				"MS", "MG", "PR", "PB", "PA", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SE", "SP",
				"TO"};
		int estadoFornecedor = 0;
		for (int i = 0; i < vetorUf.length; i++) {
			if(vetorUf[i].equals(f.getEndereco().getEstado())){
				estadoFornecedor = i;
				break;
			}
		}
		
		
		JLabel lblEndereo = new JLabel("Endere�o:");
		GridBagConstraints gbc_lblEndereo = new GridBagConstraints();
		gbc_lblEndereo.anchor = GridBagConstraints.WEST;
		gbc_lblEndereo.insets = new Insets(0, 0, 5, 5);
		gbc_lblEndereo.gridx = 0;
		gbc_lblEndereo.gridy = 4;
		layeredPane.add(lblEndereo, gbc_lblEndereo);
		
		JLabel lblCidade = new JLabel("Cidade");
		GridBagConstraints gbc_lblCidade = new GridBagConstraints();
		gbc_lblCidade.anchor = GridBagConstraints.WEST;
		gbc_lblCidade.insets = new Insets(0, 0, 5, 5);
		gbc_lblCidade.gridx = 0;
		gbc_lblCidade.gridy = 5;
		layeredPane.add(lblCidade, gbc_lblCidade);
		
		txtCidade = new JTextField(f.getEndereco().getCidade());
		txtCidade.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtCidade.setText(txtCidade.getText().toUpperCase());
			}
		});
		
		JLabel lblUf = new JLabel("UF");
		GridBagConstraints gbc_lblUf = new GridBagConstraints();
		gbc_lblUf.anchor = GridBagConstraints.WEST;
		gbc_lblUf.insets = new Insets(0, 0, 5, 0);
		gbc_lblUf.gridx = 7;
		gbc_lblUf.gridy = 5;
		layeredPane.add(lblUf, gbc_lblUf);
		GridBagConstraints gbc_txtCidade = new GridBagConstraints();
		gbc_txtCidade.gridwidth = 7;
		gbc_txtCidade.insets = new Insets(0, 0, 5, 5);
		gbc_txtCidade.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCidade.gridx = 0;
		gbc_txtCidade.gridy = 6;
		layeredPane.add(txtCidade, gbc_txtCidade);
		txtCidade.setColumns(10);
		
		comboBoxUf = new JComboBox(vetorUf);
		comboBoxUf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JComboBox situacao = (JComboBox)arg0.getSource();
				String conteudo = (String)situacao.getSelectedItem();
			}
		});
		
		comboBoxUf.setSelectedIndex(estadoFornecedor);
		
		GridBagConstraints gbc_txtUF = new GridBagConstraints();
		gbc_txtUF.insets = new Insets(0, 0, 5, 0);
		gbc_txtUF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtUF.gridx = 7;
		gbc_txtUF.gridy = 6;
		layeredPane.add(comboBoxUf, gbc_txtUF);
		
		JLabel lblLogradouro = new JLabel("Logradouro");
		GridBagConstraints gbc_lblLogradouro = new GridBagConstraints();
		gbc_lblLogradouro.anchor = GridBagConstraints.WEST;
		gbc_lblLogradouro.insets = new Insets(0, 0, 5, 5);
		gbc_lblLogradouro.gridx = 0;
		gbc_lblLogradouro.gridy = 7;
		layeredPane.add(lblLogradouro, gbc_lblLogradouro);
		
		txtLogradouro = new JTextField(f.getEndereco().getLogradouro());
		txtLogradouro.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtLogradouro.setText(txtLogradouro.getText().toUpperCase());
			}
		});
		
		JLabel lblNmero = new JLabel("N�mero");
		GridBagConstraints gbc_lblNmero = new GridBagConstraints();
		gbc_lblNmero.anchor = GridBagConstraints.WEST;
		gbc_lblNmero.insets = new Insets(0, 0, 5, 0);
		gbc_lblNmero.gridx = 7;
		gbc_lblNmero.gridy = 7;
		layeredPane.add(lblNmero, gbc_lblNmero);
		
		GridBagConstraints gbc_txtLogradouro = new GridBagConstraints();
		gbc_txtLogradouro.gridwidth = 7;
		gbc_txtLogradouro.insets = new Insets(0, 0, 5, 5);
		gbc_txtLogradouro.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLogradouro.gridx = 0;
		gbc_txtLogradouro.gridy = 8;
		layeredPane.add(txtLogradouro, gbc_txtLogradouro);
		txtLogradouro.setColumns(10);
		
		txtNumero = new JTextField(f.getEndereco().getNumero());
		txtNumero.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtNumero.setText(txtNumero.getText().replaceAll("[^0-9]", ""));
			}
		});
		GridBagConstraints gbc_txtNumero = new GridBagConstraints();
		gbc_txtNumero.insets = new Insets(0, 0, 5, 0);
		gbc_txtNumero.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNumero.gridx = 7;
		gbc_txtNumero.gridy = 8;
		layeredPane.add(txtNumero, gbc_txtNumero);
		txtNumero.setColumns(10);
		
		JLabel lblComplemento = new JLabel("Complemento");
		GridBagConstraints gbc_lblComplemento = new GridBagConstraints();
		gbc_lblComplemento.anchor = GridBagConstraints.WEST;
		gbc_lblComplemento.insets = new Insets(0, 0, 5, 5);
		gbc_lblComplemento.gridx = 0;
		gbc_lblComplemento.gridy = 9;
		layeredPane.add(lblComplemento, gbc_lblComplemento);
		
		txtComplemento = new JTextField(f.getEndereco().getComplemento());
		txtComplemento.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtComplemento.setText(txtComplemento.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtComplemento = new GridBagConstraints();
		gbc_txtComplemento.gridwidth = 8;
		gbc_txtComplemento.insets = new Insets(0, 0, 5, 0);
		gbc_txtComplemento.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtComplemento.gridx = 0;
		gbc_txtComplemento.gridy = 10;
		layeredPane.add(txtComplemento, gbc_txtComplemento);
		txtComplemento.setColumns(10);
		
		JLabel lblBairro = new JLabel("Bairro");
		GridBagConstraints gbc_lblBairro = new GridBagConstraints();
		gbc_lblBairro.anchor = GridBagConstraints.WEST;
		gbc_lblBairro.insets = new Insets(0, 0, 5, 5);
		gbc_lblBairro.gridx = 0;
		gbc_lblBairro.gridy = 11;
		layeredPane.add(lblBairro, gbc_lblBairro);
		
		txtBairro = new JTextField(f.getEndereco().getBairro());
		txtBairro.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtBairro.setText(txtBairro.getText().toUpperCase());
			}
		});
		
		JLabel lblCep = new JLabel("Cep");
		GridBagConstraints gbc_lblCep = new GridBagConstraints();
		gbc_lblCep.anchor = GridBagConstraints.WEST;
		gbc_lblCep.insets = new Insets(0, 0, 5, 5);
		gbc_lblCep.gridx = 2;
		gbc_lblCep.gridy = 11;
		layeredPane.add(lblCep, gbc_lblCep);
		GridBagConstraints gbc_txtBairro = new GridBagConstraints();
		gbc_txtBairro.gridwidth = 2;
		gbc_txtBairro.insets = new Insets(0, 0, 0, 5);
		gbc_txtBairro.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtBairro.gridx = 0;
		gbc_txtBairro.gridy = 12;
		layeredPane.add(txtBairro, gbc_txtBairro);
		txtBairro.setColumns(10);
		
		formattedTextFieldCep = new JFormattedTextField(mascara("#####-###"));
		
		GridBagConstraints gbc_formattedTextFieldCep = new GridBagConstraints();
		gbc_formattedTextFieldCep.insets = new Insets(0, 0, 0, 5);
		gbc_formattedTextFieldCep.gridwidth = 3;
		gbc_formattedTextFieldCep.fill = GridBagConstraints.HORIZONTAL;
		gbc_formattedTextFieldCep.gridx = 2;
		gbc_formattedTextFieldCep.gridy = 12;
		layeredPane.add(formattedTextFieldCep, gbc_formattedTextFieldCep);
		
		formattedTextFieldCep.setText(f.getEndereco().getCep());
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnSalvar = new JButton("Salvar (F2)");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txtNome.getText().equals("") 
						|| txtEmail.getText().equals("")
						|| formattedTextFieldCnpj.getText().equals("")
						|| formattedTextFieldTelefone.getText().equals("")  
						|| formattedTextFieldCep.getText().equals("") 
						|| txtLogradouro.getText().equals("") 
						|| txtNumero.getText().equals("") 
						|| txtComplemento.getText().equals("")
						|| txtBairro.getText().equals("") 
						|| txtCidade.getText().equals("")) {
					JOptionPane.showMessageDialog(contentPane.getParent(), "Preencha todos os campos");
				} else {
					
					boolean  okendereco = EnderecoDAO.atualizarEndereco(txtLogradouro.getText(), txtNumero.getText(), txtComplemento.getText(),
							txtBairro.getText(), txtCidade.getText(), comboBoxUf.getSelectedItem().toString(), formattedTextFieldCep.getText(),
							f.getEndereco().getCodEndereco());
					
					FornecedorDAO.atualizarFornecedor(txtNome.getText(), formattedTextFieldCnpj.getText(), formattedTextFieldTelefone.getText(),
							txtEmail.getText(), Integer.parseInt(txtCodifoFornecedor.getText()));
					
					dispose();
					JOptionPane.showMessageDialog(contentPane.getParent(), "Edi��o realizada com sucesso.");
					//limparCampos();
				}
			}
		});
		btnSalvar.setIcon(new ImageIcon(EditarFornecedor.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.WEST;
		gbc_btnSalvar.insets = new Insets(0, 0, 0, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 0;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JButton btnFechar = new JButton("Fechar (ESC)");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//JOptionPane.showConfirmDialog(null, "Deseja fechar a janela?");
				int resposta = JOptionPane.showConfirmDialog(null, "Deseja fechar a janela?",
			    		"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
			    
			    switch(resposta){
			    case JOptionPane.YES_OPTION:
			    	dispose();
			    	break;
			    case JOptionPane.NO_OPTION:
					
					
					break;
					default:
						break;
			    }
			    
				
			}
		});
		btnFechar.setIcon(new ImageIcon(EditarFornecedor.class.getResource("/imagens/fechar32.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.anchor = GridBagConstraints.EAST;
		gbc_btnFechar.gridx = 6;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);
	}
	
	
	//=-=-=-=- MÉTODO UTILIZADO NA SOLUÇÃO 1 =-=-=-=-=-=-
		public MaskFormatter mascara(String Mascara){
	        MaskFormatter F_Mascara = new MaskFormatter();
	        try{
	            F_Mascara.setMask(Mascara); //Atribui a mascara
	            F_Mascara.setPlaceholderCharacter('_'); //Caracter para preenchimento 
	        }
	        catch (Exception excecao) {
	        excecao.printStackTrace();
	        } 
	        return F_Mascara;
	 }
		
		/*public void limparCampos(){
			
			
			txtNome.setText("");
			formattedTextFieldCnpj.setText("");
			formattedTextFieldTelefone.setText("");
			txtEmail.setText("");
			txtCidade.setText("");
			comboBoxUf.setSelectedIndex(0);
			txtLogradouro.setText("");
			txtNumero.setText("");
			txtComplemento.setText("");
			txtBairro.setText("");
			formattedTextFieldCep.setText("");
			
		}*/
	
}
