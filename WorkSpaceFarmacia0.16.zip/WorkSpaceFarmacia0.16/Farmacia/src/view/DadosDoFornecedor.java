package view;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import model.Cliente;
import model.Endereco;
import model.Fornecedor;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.FornecedorDAO;
import view.TM.TabelaCliente;
import view.TM.TabelaFornecedor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class DadosDoFornecedor extends JFrame {

	private JPanel contentPane;
	private JTextField txtPesquisarPor;
	private JFormattedTextField formattedTextFieldPesquisarPorCnpj;

	String opcaoNome = " Pesquisar fornecedor j\u00E1 cadastrado por [Nome]";
	String opcaoCnpj = " Pesquisar fornecedor j\u00E1 cadastrado por [CNPJ]";

	JLabel lblPesquisarPor = new JLabel(opcaoNome);
	GridBagConstraints gbc_lblPesquisarPor = new GridBagConstraints();
	private JTable table;

	int codFornecedor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DadosDoFornecedor fornecedor = new DadosDoFornecedor();
					fornecedor.setVisible(true);
					fornecedor.setResizable(false);
					fornecedor.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DadosDoFornecedor() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 767, 534);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] { 815, 0 };
		gbl_contentPane.rowHeights = new int[] { 14, 289, 0, 0, 0, 0, 0, 0, 0 };
		gbl_contentPane.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_contentPane.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		contentPane.setLayout(gbl_contentPane);

		JLabel lblFornecedor = new JLabel("Fornecedor");
		GridBagConstraints gbc_lblFornecedor = new GridBagConstraints();
		gbc_lblFornecedor.anchor = GridBagConstraints.NORTH;
		gbc_lblFornecedor.insets = new Insets(0, 0, 5, 0);
		gbc_lblFornecedor.gridx = 0;
		gbc_lblFornecedor.gridy = 0;
		contentPane.add(lblFornecedor, gbc_lblFornecedor);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

		JLayeredPane layeredPaneListaDeFornecedor = new JLayeredPane();
		layeredPaneListaDeFornecedor.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tabbedPane.addTab("Lista dos Fornecedores", null, layeredPaneListaDeFornecedor, null);
		GridBagLayout gbl_layeredPaneListaDeFornecedor = new GridBagLayout();
		gbl_layeredPaneListaDeFornecedor.columnWidths = new int[] { 0, 0 };
		gbl_layeredPaneListaDeFornecedor.rowHeights = new int[] { 0, 0 };
		gbl_layeredPaneListaDeFornecedor.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_layeredPaneListaDeFornecedor.rowWeights = new double[] { 1.0, Double.MIN_VALUE };
		layeredPaneListaDeFornecedor.setLayout(gbl_layeredPaneListaDeFornecedor);

		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 0;
		layeredPaneListaDeFornecedor.add(scrollPane, gbc_scrollPane);

		/*
		 * table.setModel(new DefaultTableModel( new Object[][] {
		 * 
		 * }, new String[] { "C�digo", "Nome", "Telefone", "Email", "Sexo",
		 * "CPF", "RG", "Nascimento", "Situa��o" } ));
		 * scrollPane.setViewportView(table);
		 */

		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 4;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		contentPane.add(tabbedPane, gbc_tabbedPane);

		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.gridheight = 5;
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 5;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		// local da label Pesquisar produto por
		gbc_lblPesquisarPor.gridwidth = 3;
		gbc_lblPesquisarPor.insets = new Insets(0, 0, 5, 5);
		gbc_lblPesquisarPor.anchor = GridBagConstraints.WEST;
		gbc_lblPesquisarPor.gridx = 0;
		gbc_lblPesquisarPor.gridy = 0;
		panel.add(lblPesquisarPor, gbc_lblPesquisarPor);

		txtPesquisarPor = new JTextField();
		txtPesquisarPor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				txtPesquisarPor.setText(txtPesquisarPor.getText().toUpperCase());
			}
		});
		GridBagConstraints gbc_txtPesquisarPor = new GridBagConstraints();
		gbc_txtPesquisarPor.gridwidth = 5;
		gbc_txtPesquisarPor.insets = new Insets(0, 0, 5, 5);
		gbc_txtPesquisarPor.fill = GridBagConstraints.BOTH;
		gbc_txtPesquisarPor.gridx = 0;
		gbc_txtPesquisarPor.gridy = 1;
		panel.add(txtPesquisarPor, gbc_txtPesquisarPor);
		txtPesquisarPor.setColumns(10);

		formattedTextFieldPesquisarPorCnpj = new JFormattedTextField(mascara("##.###.###/####-##"));

		GridBagConstraints gbc_formattedTextFieldPesquisarPorCnpj = new GridBagConstraints();
		gbc_formattedTextFieldPesquisarPorCnpj.gridwidth = 5;
		gbc_formattedTextFieldPesquisarPorCnpj.insets = new Insets(0, 0, 5, 5);
		gbc_formattedTextFieldPesquisarPorCnpj.fill = GridBagConstraints.BOTH;
		gbc_formattedTextFieldPesquisarPorCnpj.gridx = 0;
		gbc_formattedTextFieldPesquisarPorCnpj.gridy = 1;
		panel.add(formattedTextFieldPesquisarPorCnpj, gbc_formattedTextFieldPesquisarPorCnpj);
		formattedTextFieldPesquisarPorCnpj.setVisible(false);
		// ===================================================================================

		JButton btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				CadastroFornecedor cadFornecedor = new CadastroFornecedor();
				cadFornecedor.setVisible(true);
				cadFornecedor.setResizable(false);
				cadFornecedor.setLocationRelativeTo(null);

			}
		});

		JPanel painelModosDePesquisas = new JPanel();
		painelModosDePesquisas.setBorder(new TitledBorder(null, "Modos de pesquisas dispon\u00EDveis:",
				TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 2;
		gbc_panel_1.gridheight = 3;
		gbc_panel_1.insets = new Insets(0, 0, 5, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 5;
		gbc_panel_1.gridy = 0;
		panel.add(painelModosDePesquisas, gbc_panel_1);
		painelModosDePesquisas.setLayout(new GridLayout(2, 1));

		JRadioButton radioButtonNome = new JRadioButton("Nome");
		// Isto vai fazer com que ao clicar no bot�o, o Listener receba a
		// palavra
		// �Nome�
		radioButtonNome.setActionCommand("Nome");
		radioButtonNome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lblPesquisarPor.setText(opcaoNome);
				txtPesquisarPor.setText("");
				formattedTextFieldPesquisarPorCnpj.setVisible(false);
				txtPesquisarPor.setVisible(true);

			}
		});
		radioButtonNome.setSelected(true);
		painelModosDePesquisas.add(radioButtonNome);

		JRadioButton radioButtonCnpj = new JRadioButton("CNPJ");

		// Isto vai fazer com que ao clicar no bot�o, o Listener receba a
		// palavra
		// �CPF�
		radioButtonCnpj.setActionCommand("CNPJ");
		radioButtonCnpj.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lblPesquisarPor.setText(opcaoCnpj);
				formattedTextFieldPesquisarPorCnpj.setVisible(true);
				formattedTextFieldPesquisarPorCnpj.setText("");
				txtPesquisarPor.setVisible(false);

			}
		});
		painelModosDePesquisas.add(radioButtonCnpj);

		ButtonGroup grupo = new ButtonGroup();
		grupo.add(radioButtonNome);
		grupo.add(radioButtonCnpj);

		btnNovo.setIcon(new ImageIcon(DadosDoFornecedor.class.getResource("/imagens/novo2.png")));
		GridBagConstraints gbc_btnNovo = new GridBagConstraints();
		gbc_btnNovo.insets = new Insets(0, 0, 0, 5);
		gbc_btnNovo.fill = GridBagConstraints.VERTICAL;
		gbc_btnNovo.anchor = GridBagConstraints.WEST;
		gbc_btnNovo.gridx = 0;
		gbc_btnNovo.gridy = 2;
		panel.add(btnNovo, gbc_btnNovo);

		JButton btnApagar = new JButton("Apagar");
		btnApagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int resposta = 0;

				resposta = JOptionPane.showConfirmDialog(null, "Deseja excluir o Fornecedor?", "Janela de confirma��o",
						JOptionPane.YES_NO_OPTION);
				if (resposta == JOptionPane.YES_OPTION) {
					// essa linha apagar o fornecedor pelo c�digo que veio da
					// sele��o na tabela
					Fornecedor f = FornecedorDAO.buscarPorCodigo(codFornecedor);
					FornecedorDAO.excluirFornecedor(codFornecedor);
					EnderecoDAO.excluirEndereco(f.getEndereco().getCodEndereco());
					JOptionPane.showMessageDialog(null, "Fornecedor excluido com sucesso.");
				}

			}
		});
		btnApagar.setEnabled(false);
		btnApagar.setIcon(new ImageIcon(DadosDoFornecedor.class.getResource("/imagens/Apagar24.png")));
		GridBagConstraints gbc_btnApagar = new GridBagConstraints();
		gbc_btnApagar.insets = new Insets(0, 0, 0, 5);
		gbc_btnApagar.gridx = 1;
		gbc_btnApagar.gridy = 2;
		panel.add(btnApagar, gbc_btnApagar);

		JButton btnEditar = new JButton("Editar");
		btnEditar.setEnabled(false);
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				Fornecedor f = FornecedorDAO.buscarPorCodigo(codFornecedor);
				Endereco e = EnderecoDAO.buscarPorCodigo(f.getEndereco().getCodEndereco());
				f.setEndereco(e);

				EditarFornecedor editar = new EditarFornecedor(f);
				editar.setVisible(true);
				editar.setResizable(false);
				editar.setLocationRelativeTo(null);

			}
		});
		btnEditar.setIcon(new ImageIcon(DadosDoFornecedor.class.getResource("/imagens/editar.png")));
		GridBagConstraints gbc_btnEditar = new GridBagConstraints();
		gbc_btnEditar.insets = new Insets(0, 0, 0, 5);
		gbc_btnEditar.gridx = 2;
		gbc_btnEditar.gridy = 2;
		panel.add(btnEditar, gbc_btnEditar);

		List<Fornecedor> fornecedor = FornecedorDAO.buscarTodosFornecedor();
		TabelaFornecedor tabelaFornecedor;

		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				// pega o c�digo do cliente na linha que o usu�rio selecionar
				// e armazena na vari�vel global codCliente
				codFornecedor = (int) table.getValueAt(table.getSelectedRow(), 0);

				btnApagar.setEnabled(true);
				btnEditar.setEnabled(true);

			}
		});
		tabelaFornecedor = new TabelaFornecedor(fornecedor);
		table.setModel(tabelaFornecedor);
		scrollPane.setViewportView(table);

		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Recebe o texto do radioButton
				String comando = grupo.getSelection().getActionCommand();

				List<Fornecedor> f = null;

				// se o texto do radioButton for igual a "Nome"
				if (comando.equals("Nome")) {

					
						f = FornecedorDAO.buscarPorNome(txtPesquisarPor.getText());
						
						TabelaFornecedor tabelaFornecedor;
						tabelaFornecedor = new TabelaFornecedor(f);
						table.setModel(tabelaFornecedor); 
						
						if(f.size() == 0){
							JOptionPane.showMessageDialog(null, "Nunhum fornecedor encontrado.");
						}
						
						
					// se o texto do radioButton for igual a "Cnpj"
				} else if (comando.equals("CNPJ")) {

					if (!(formattedTextFieldPesquisarPorCnpj.getText().equals("__.___.___/____-__"))) {

						f = FornecedorDAO.buscarPorCnpj(formattedTextFieldPesquisarPorCnpj.getText());

						TabelaFornecedor tabelaFornecedor;
						tabelaFornecedor = new TabelaFornecedor(f);
						table.setModel(tabelaFornecedor);
						
						if(f.size() == 0){
							JOptionPane.showMessageDialog(null, "Nunhum fornecedor encontrado.");
						}
					} else {

						JOptionPane.showMessageDialog(null, "Digite os 14 n�meros do CNPJ.");

					}
					
					

				}

				btnApagar.setEnabled(false);
				btnEditar.setEnabled(false);

			}
		});

		btnPesquisar.setIcon(new ImageIcon(DadosDoFornecedor.class.getResource("/imagens/pesquisar.png")));
		GridBagConstraints gbc_btnPesquisar = new GridBagConstraints();
		gbc_btnPesquisar.insets = new Insets(0, 0, 0, 5);
		gbc_btnPesquisar.gridx = 3;
		gbc_btnPesquisar.gridy = 2;
		panel.add(btnPesquisar, gbc_btnPesquisar);

		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				dispose();

			}
		});
		btnFechar.setIcon(new ImageIcon(DadosDoFornecedor.class.getResource("/imagens/fechar.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.insets = new Insets(0, 0, 0, 5);
		gbc_btnFechar.gridx = 4;
		gbc_btnFechar.gridy = 2;
		panel.add(btnFechar, gbc_btnFechar);

	}

	// =-=-=-=- MÉTODO UTILIZADO NA SOLUÇÃO 1 =-=-=-=-=-=-
	public MaskFormatter mascara(String Mascara) {
		MaskFormatter F_Mascara = new MaskFormatter();
		try {
			F_Mascara.setMask(Mascara); // Atribui a mascara
			F_Mascara.setPlaceholderCharacter('_'); // Caracter para
													// preenchimento
		} catch (Exception excecao) {
			excecao.printStackTrace();
		}
		return F_Mascara;
	}
}
