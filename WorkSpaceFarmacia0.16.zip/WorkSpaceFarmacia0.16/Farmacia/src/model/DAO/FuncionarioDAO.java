package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import model.Funcionario;
import util.Conexao;

public class FuncionarioDAO {
	
	public static Funcionario cadastrarFuncionario(String login, String senha, int tipo, String descricao, int matricula, 
			String nome, String telefone, String email, String sexo, String cpf, String rg, String nascimento, double salario) {
		
		Funcionario funcionario = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO funcionario (matricula, nome, telefone, email, sexo, cpf, rg, nascimento, salario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, matricula);
			stmt.setString(2, nome);
			stmt.setString(3, telefone);
			stmt.setString(4, email);
			stmt.setString(5, sexo);
			stmt.setString(6, cpf);
			stmt.setString(7, rg);
			stmt.setString(8, nascimento);
			stmt.setDouble(9, salario);

			stmt.executeUpdate();
			
			funcionario = new Funcionario(login, senha, tipo, descricao, matricula, nome, telefone, email, sexo, cpf, rg, nascimento, salario);

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return funcionario;
	}
	
	public static List<Funcionario> consultarTodosFuncionario() {
		
		List<Funcionario> lista = new LinkedList<>();
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM funcionario";
		
		try {
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while(rs.next()){
				Funcionario f = new Funcionario();
				f.setMatricula(rs.getInt("matricula"));
				f.setNome(rs.getString("nome"));
				f.setTelefone(rs.getString("telefone"));
				f.setEmail(rs.getString("email"));
				f.setSexo(rs.getString("sexo"));
				f.setCpf(rs.getString("cpf"));
				f.setRg(rs.getString("rg"));
				f.setNascimento(rs.getString("nascimento"));
				f.setSalario(rs.getDouble("salario"));
				
				lista.add(f);
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return lista;
	}
	
	public static Funcionario buscarPorMatricula(int matricula){
		
		Funcionario funcionario = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM funcionario WHERE matricula = ?";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, matricula);
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				funcionario = new Funcionario();
				funcionario.setNome(rs.getString("nome"));
				funcionario.setTelefone(rs.getString("telefone"));
				funcionario.setEmail(rs.getString("email"));
				funcionario.setSexo(rs.getString("sexo"));
				funcionario.setCpf(rs.getString("cpf"));
				funcionario.setRg(rs.getString("rg"));
				funcionario.setNascimento(rs.getString("nascimento"));
				funcionario.setSalario(rs.getDouble("salario"));
			}
			
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return funcionario;
	}
	
	public static boolean excluirFuncionario(int matricula){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "DELETE FROM funcionario WHERE matricula = ?";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, matricula);
			
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static boolean atualizarFuncionario(String login, String senha, int tipo, String descricao, String nome, String telefone, 
			String email, String sexo, String cpf, String rg, String nascimento, double salario){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "UPDATE funcionario SET nome = ?, telefone = ?, email = ?, sexo = ?, cpf = ?, rg = ?, nascimento = ?, salario = ? WHERE matricula = ?";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			stmt.setString(2, telefone);
			stmt.setString(3, email);
			stmt.setString(4, sexo);
			stmt.setString(5, sexo);
			stmt.setString(6, cpf);
			stmt.setString(7, rg);
			stmt.setString(8, nascimento);
			stmt.setDouble(9, salario);
			
			ok = stmt.executeUpdate() > 0;

			con.close();
			stmt.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static Funcionario buscarPorLoginSenha(String login, String senha) {
		
		Funcionario funcionario = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		try {
			
			String sql = "SELECT * FROM usuario AS u, funcionario AS f WHERE u.login = f.fklogin AND u.login = ? AND u.senha = ?";
			
			PreparedStatement comando = con.prepareStatement(sql);
			
			comando.setString(1, login);
			comando.setString(2, senha);
			
			ResultSet rs = comando.executeQuery();
			
			if(rs.next()) {
				funcionario = new Funcionario(
						rs.getString("login"), 
						rs.getString("senha"), 
						rs.getInt("tipo"), 
						rs.getString("descricao"), 
						rs.getString("nome"), 
						rs.getString("telefone"), 
						rs.getString("email"), 
						rs.getString("sexo"), 
						rs.getString("cpf"), 
						rs.getString("rg"),
						rs.getString("nascimento"), 
						rs.getDouble("salario"));
			}
			
			rs.close();
			comando.close();
			con.close();
			
			} catch (Exception e) {
			 System.out.println(e.getMessage());
		}
			
		return funcionario;
	}

}