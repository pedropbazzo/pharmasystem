package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Administrador;
import util.Conexao;

public class AdministradorDAO {
	
	public static Administrador cadastrarCliente(String login, String senha, int tipo, String descricao, int matricula) {
		
		Administrador adm = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO administrador (matricula) VALUES (?)";
		
		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, matricula);
			
			adm = new Administrador(login, senha, tipo, descricao, matricula);
			
			con.close();
			stmt.close();
			

		} catch(SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return adm;
	}
	
	public static Administrador buscarPorLoginSenha(String login, String senha) {
		
		Administrador administrador = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		try {
			
			String sql = "SELECT * FROM usuario AS u, administrador AS a WHERE u.login = a.fklogin AND u.login = ? AND u.senha = ?";
			
			PreparedStatement comando = con.prepareStatement(sql);
			
			comando.setString(1, login);
			comando.setString(2, senha);
			
			ResultSet rs = comando.executeQuery();
			
			if(rs.next()) {
				administrador = new Administrador(
						rs.getString("login"), 
						rs.getString("senha"), 
						rs.getInt("tipo"), 
						rs.getString("descricao"), 
						rs.getInt("matricula"));
			}
			
			rs.close();
			comando.close();
			con.close();
			
			} catch (Exception e) {
			 System.out.println(e.getMessage());
		}
			
		return administrador;
	}
	
}