package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import model.Categoria;
import model.Fornecedor;
import util.Conexao;

public class CategoriaDAO {
	
public static Categoria cadastrarCategoria(String nome){
		
		Categoria categoria = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO categoria (nome) VALUES (?)";
		
		try {

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);

			stmt.executeUpdate();

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return categoria;
	}
	
	public static boolean excluirCategoria(String nome){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "DELETE FROM categoria WHERE nome = ? LIMIT 1";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static List<Categoria> consultarTodasCategoria() {
		
		List<Categoria> lista = new LinkedList<>();
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "SELECT * FROM categoria";
		
		try {
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while(rs.next()){
				Categoria c = new Categoria();
				c.setNomeCategoria(rs.getString("nome"));
				
				lista.add(c);
			}
			
			rs.close();
			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return lista;
	}
	
	public static boolean atualizarCategoria(String nome, int codCategoria){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "UPDATE categoria SET nome = ? WHERE codCategoria = ?";

		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			stmt.setInt(2, codCategoria);
	
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}	

}