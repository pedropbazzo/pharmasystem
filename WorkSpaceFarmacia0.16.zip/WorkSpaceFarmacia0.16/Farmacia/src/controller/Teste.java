package controller;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double valor1 = 3333.33;
		double valor2 = 2;
		
		System.out.println("5 dividido por 2 = " + (valor1 / valor2));
		
	}

}
