package controller;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class TesteMascara extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TesteMascara frame = new TesteMascara();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TesteMascara() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 367, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);

		// =-=-=-=-=-=-=-SOLUÇÃO 1:=-=-=-=-=-=-=-=-=-=-=-

		JLabel lblSoluo = new JLabel("Solução 1:");
		panel.add(lblSoluo);

		JFormattedTextField formattedTextField = new JFormattedTextField(mascara("###.###.###-##"));
		formattedTextField.setColumns(20);
		panel.add(formattedTextField);
		// =-=-=-=-=--FIM DA SOLUÇÃO 1 =-==-=-=-=-=-=-=-=-

		// =-=-=-=-=-=-=- SOLUÇÃO 2 =-=-=-=-=-=-=-=-=-=-=-

		JLabel lblSoluo_1 = new JLabel("Solução 2:");
		panel.add(lblSoluo_1);

		MaskFormatter cpf;
		try {
			cpf = new MaskFormatter("###.###.###-##");
			textField = new JFormattedTextField(cpf);
			panel.add(textField);
			textField.setColumns(20);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// =-=-=-=-=--FIM DA SOLUÇÃO 2 =-==-=-=-=-=-=-=-=-

		// =-=-=-=-=-=-=- SOLUÇÃO 3 =-=-=-=-=-=-=-=-=-=-=-
		JLabel lblSoluo_2 = new JLabel("Solução 3:");
		panel.add(lblSoluo_2);

		JFormattedTextField formattedTextField_1 = new JFormattedTextField();

		try {
			formattedTextField_1.setFormatterFactory(new DefaultFormatterFactory(new MaskFormatter("###.###.###-##")));
			formattedTextField_1.setColumns(20);
			panel.add(formattedTextField_1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// =-=-=-=-=--FIM DA SOLUÇÃO 3 =-==-=-=-=-=-=-=-=-

		JButton btnExibe = new JButton("Exibe");
		btnExibe.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				String[] vetorSolucao1 = formattedTextField.getText().split("[-.]");
				String[] vetorSolucao2 = textField.getText().split("[-.]");
				String[] vetorSolucao3 = formattedTextField_1.getText().split("[-.]");

				StringBuffer stringSolucao1 = new StringBuffer();
				StringBuffer stringSolucao2 = new StringBuffer();
				StringBuffer stringSolucao3 = new StringBuffer();

				// como os 3 vetores possuem o mesmo tamanho, fiz uso de apenas
				// um for
				for (int i = 0; i < vetorSolucao1.length; i++) {
					stringSolucao1.append(vetorSolucao1[i]);
					stringSolucao2.append(vetorSolucao2[i]);
					stringSolucao3.append(vetorSolucao3[i]);
				}

				// para salvar no banco em formato numérico (int, double, long,
				// ...) é necessário aplicar a conversão correspondente para
				// cada tipo.
				// Exemplo para conversão de String para long:
				// Long.parseLong(stringSolucao1.toString());
				JOptionPane.showMessageDialog(btnExibe.getParent(),
						"Solução 1: " + stringSolucao1.toString() + "\nSolução 2: " + stringSolucao2.toString()
								+ "\nSolução 3: " + stringSolucao3.toString());

			}
		});
		panel.add(btnExibe);
	}

	// =-=-=-=- MÉTODO UTILIZADO NA SOLUÇÃO 1 =-=-=-=-=-=-
	public MaskFormatter mascara(String Mascara) {
		MaskFormatter F_Mascara = new MaskFormatter();
		try {
			F_Mascara.setMask(Mascara); // Atribui a mascara
			F_Mascara.setPlaceholderCharacter('_'); // Caracter para
													// preenchimento
		} catch (Exception excecao) {
			excecao.printStackTrace();
		}
		return F_Mascara;
	}

}
