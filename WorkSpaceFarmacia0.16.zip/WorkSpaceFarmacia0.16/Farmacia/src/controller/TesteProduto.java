package controller;

public class TesteProduto {

	public static void main(String[] args) {
	/*	List<Produto> lista = ProdutoDAO.buscarTodos();
		if(!lista.isEmpty()){
			new TabelaProduto(lista);
		}else{
			System.out.println("Nunhum contato cadastrado.");
		}*/

	}

}
